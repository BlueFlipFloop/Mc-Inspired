package dev.miyam.voxelsandbox.game.biomes;

import dev.miyam.voxelsandbox.game.blocks.BlockType;

public enum BiomeType {
    OCEAN(new BiomeProfile("ocean", 34.0f, 3.0f, 0.0f, 4.0f, 0.0f, 1.1f, 0.0f, BlockType.SAND, BlockType.SAND, BlockType.SAND, false)),
    RIVER(new BiomeProfile("river", 44.0f, 4.0f, 0.0f, 3.0f, 0.02f, 0.90f, 1.0f, BlockType.GRASS, BlockType.DIRT, BlockType.SAND, false)),
    PLAINS(new BiomeProfile("plains", 49.0f, 6.0f, 0.12f, 4.0f, 0.05f, 0.82f, 0.45f, BlockType.GRASS, BlockType.DIRT, BlockType.SAND, false)),
    FOREST(new BiomeProfile("forest", 50.0f, 8.0f, 0.18f, 4.0f, 0.12f, 0.72f, 0.42f, BlockType.GRASS, BlockType.DIRT, BlockType.SAND, false)),
    DESERT(new BiomeProfile("desert", 47.0f, 5.0f, 0.10f, 6.0f, 0.0f, 1.1f, 0.28f, BlockType.SAND, BlockType.SAND, BlockType.SAND, false)),
    MOUNTAINS(new BiomeProfile("mountains", 56.0f, 12.0f, 1.0f, 2.0f, 0.02f, 0.90f, 0.18f, BlockType.SNOW_GRASS, BlockType.STONE, BlockType.STONE, false)),
    BLOSSOM_GROVE(new BiomeProfile("blossom_grove", 53.0f, 9.0f, 0.22f, 4.0f, 0.18f, 0.63f, 0.35f, BlockType.LUSH_GRASS, BlockType.DIRT, BlockType.SAND, true));

    private final BiomeProfile profile;

    BiomeType(BiomeProfile profile) {
        this.profile = profile;
    }

    public BiomeProfile profile() {
        return profile;
    }
}
