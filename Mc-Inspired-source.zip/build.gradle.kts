import org.gradle.api.JavaVersion

plugins {
    application
    java
}

group = "dev.miyam"
version = "0.1.0"

repositories {
    mavenCentral()
}

val lwjglVersion = "3.3.6"
val jomlVersion = "1.10.8"
val junitVersion = "5.12.2"

val osName = System.getProperty("os.name").lowercase()
val osArch = System.getProperty("os.arch").lowercase()
val lwjglNatives = when {
    osName.contains("win") -> "natives-windows"
    osName.contains("mac") && osArch.contains("aarch64") -> "natives-macos-arm64"
    osName.contains("mac") -> "natives-macos"
    osArch.contains("aarch64") -> "natives-linux-arm64"
    osArch.contains("arm") -> "natives-linux-arm32"
    else -> "natives-linux"
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

application {
    mainClass = "dev.miyam.voxelsandbox.game.VoxelSandboxGame"
}

dependencies {
    implementation(platform("org.lwjgl:lwjgl-bom:$lwjglVersion"))
    implementation("org.lwjgl:lwjgl")
    implementation("org.lwjgl:lwjgl-glfw")
    implementation("org.lwjgl:lwjgl-opengl")
    implementation("org.lwjgl:lwjgl-stb")
    implementation("org.lwjgl:lwjgl-openal")
    implementation("org.joml:joml:$jomlVersion")

    runtimeOnly("org.lwjgl:lwjgl::$lwjglNatives")
    runtimeOnly("org.lwjgl:lwjgl-glfw::$lwjglNatives")
    runtimeOnly("org.lwjgl:lwjgl-opengl::$lwjglNatives")
    runtimeOnly("org.lwjgl:lwjgl-stb::$lwjglNatives")
    runtimeOnly("org.lwjgl:lwjgl-openal::$lwjglNatives")

    testImplementation(platform("org.junit:junit-bom:$junitVersion"))
    testImplementation("org.junit.jupiter:junit-jupiter")
}

tasks.test {
    useJUnitPlatform()
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release = 21
}

tasks.withType<JavaExec>().configureEach {
    workingDir = project.layout.projectDirectory.asFile
    if (osName.contains("mac")) {
        jvmArgs("-XstartOnFirstThread")
    }
}

