package dev.miyam.voxelsandbox.engine;

import dev.miyam.voxelsandbox.engine.audio.AudioEngine;
import dev.miyam.voxelsandbox.engine.input.InputManager;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;

public final class Engine implements AutoCloseable {
    private static final double FIXED_STEP_SECONDS = 1.0 / 120.0;

    private final EngineConfig config;
    private final ApplicationLayer layer;

    private Window window;
    private InputManager input;
    private AudioEngine audio;
    private EngineContext context;

    public Engine(EngineConfig config, ApplicationLayer layer) {
        this.config = config;
        this.layer = layer;
    }

    public void run() {
        initialize();

        double previousTime = GLFW.glfwGetTime();
        double accumulator = 0.0;

        while (!window.shouldClose()) {
            double currentTime = GLFW.glfwGetTime();
            double frameTime = Math.min(currentTime - previousTime, 0.25);
            previousTime = currentTime;
            accumulator += frameTime;

            input.beginFrame();
            window.beginFrame();

            while (accumulator >= FIXED_STEP_SECONDS) {
                layer.update(FIXED_STEP_SECONDS);
                accumulator -= FIXED_STEP_SECONDS;
            }

            layer.render(accumulator / FIXED_STEP_SECONDS);

            window.endFrame();
            input.endFrame();
        }
    }

    private void initialize() {
        window = new Window(config);
        window.create();

        GL.createCapabilities();
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_CULL_FACE);
        GL11.glCullFace(GL11.GL_BACK);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        input = new InputManager(window);
        audio = new AudioEngine();
        audio.initialize();

        context = new EngineContext(window, input, audio);
        layer.initialize(context);
        layer.resize(window.getWidth(), window.getHeight());

        window.setResizeCallback(layer::resize);
    }

    @Override
    public void close() {
        try {
            layer.dispose();
        } finally {
            if (audio != null) {
                audio.close();
            }
            if (window != null) {
                window.close();
            }
        }
    }
}
