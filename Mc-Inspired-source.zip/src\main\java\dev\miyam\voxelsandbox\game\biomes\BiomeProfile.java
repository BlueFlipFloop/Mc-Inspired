package dev.miyam.voxelsandbox.game.biomes;

import dev.miyam.voxelsandbox.game.blocks.BlockType;

public record BiomeProfile(
        String id,
        float baseHeight,
        float heightVariation,
        float mountainScale,
        float dirtDepth,
        float treeDensity,
        float treeThreshold,
        float riverCarve,
        BlockType topBlock,
        BlockType fillerBlock,
        BlockType shoreBlock,
        boolean rare
) {
}

