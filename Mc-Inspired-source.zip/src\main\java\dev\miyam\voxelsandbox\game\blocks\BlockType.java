package dev.miyam.voxelsandbox.game.blocks;

public enum BlockType {
    AIR(0, false, false, 0, 0, 0),
    GRASS(1, true, true, 0, 2, 1),
    DIRT(2, true, true, 2, 2, 2),
    STONE(3, true, true, 3, 3, 3),
    SAND(4, true, true, 4, 4, 4),
    WATER(5, true, false, 5, 5, 5),
    LOG(6, true, true, 14, 14, 6),
    LEAVES(7, true, true, 7, 7, 7),
    COAL_ORE(8, true, true, 8, 8, 8),
    IRON_ORE(9, true, true, 9, 9, 9),
    SNOW_GRASS(10, true, true, 10, 2, 11),
    LUSH_GRASS(11, true, true, 12, 2, 13);

    private static final BlockType[] LOOKUP = new BlockType[values().length];

    static {
        for (BlockType type : values()) {
            LOOKUP[type.id] = type;
        }
    }

    private final byte id;
    private final boolean solid;
    private final boolean collidable;
    private final int topTexture;
    private final int bottomTexture;
    private final int sideTexture;

    BlockType(int id, boolean solid, boolean collidable, int topTexture, int bottomTexture, int sideTexture) {
        this.id = (byte) id;
        this.solid = solid;
        this.collidable = collidable;
        this.topTexture = topTexture;
        this.bottomTexture = bottomTexture;
        this.sideTexture = sideTexture;
    }

    public byte id() {
        return id;
    }

    public boolean solid() {
        return solid;
    }

    public boolean collidable() {
        return collidable;
    }

    public int textureIndex(BlockFace face) {
        return switch (face) {
            case UP -> topTexture;
            case DOWN -> bottomTexture;
            default -> sideTexture;
        };
    }

    public static BlockType byId(byte id) {
        int index = Byte.toUnsignedInt(id);
        if (index < 0 || index >= LOOKUP.length) {
            return AIR;
        }
        return LOOKUP[index];
    }
}
