#version 410 core

in vec2 vTileUv;
in vec2 vRegionMin;
in vec2 vRegionMax;
in vec3 vNormal;
in vec3 vWorldPosition;

uniform sampler2D uAtlas;
uniform vec3 uCameraPosition;

out vec4 fragColor;

void main() {
    vec2 repeatedUv = vTileUv - floor(vTileUv);
    vec2 atlasUv = mix(vRegionMin, vRegionMax, repeatedUv);
    vec4 texel = texture(uAtlas, atlasUv);
    if (texel.a < 0.05) {
        discard;
    }

    vec3 sunDirection = normalize(vec3(0.45, 1.0, 0.35));
    float diffuse = max(dot(normalize(vNormal), sunDirection), 0.0);
    float lighting = 0.32 + diffuse * 0.68;

    float distanceToCamera = distance(vWorldPosition, uCameraPosition);
    float fogFactor = clamp((distanceToCamera - 96.0) / 120.0, 0.0, 1.0);
    vec3 fogColor = vec3(0.54, 0.75, 0.92);

    vec3 lit = texel.rgb * lighting;
    vec3 color = mix(lit, fogColor, fogFactor);
    fragColor = vec4(color, texel.a);
}

