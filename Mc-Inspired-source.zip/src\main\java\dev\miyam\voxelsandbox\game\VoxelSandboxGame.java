package dev.miyam.voxelsandbox.game;

import dev.miyam.voxelsandbox.engine.Engine;
import dev.miyam.voxelsandbox.engine.EngineConfig;

public final class VoxelSandboxGame {
    private VoxelSandboxGame() {
    }

    public static void main(String[] args) {
        EngineConfig config = new EngineConfig(
                "Voxel Sandbox",
                1600,
                900,
                true,
                true,
                false
        );

        try (Engine engine = new Engine(config, new VoxelSandbox())) {
            engine.run();
        }
    }
}
