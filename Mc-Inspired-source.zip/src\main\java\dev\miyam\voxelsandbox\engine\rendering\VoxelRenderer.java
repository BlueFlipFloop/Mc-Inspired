package dev.miyam.voxelsandbox.engine.rendering;

import dev.miyam.voxelsandbox.engine.shaders.ShaderProgram;
import dev.miyam.voxelsandbox.world.chunk.Chunk;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import dev.miyam.voxelsandbox.world.terrain.World;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public final class VoxelRenderer implements AutoCloseable {
    private final ShaderProgram shaderProgram;
    private final TextureAtlas atlas;
    private final List<World.ChunkHandle> visibleChunks = new ArrayList<>();

    public VoxelRenderer(TextureAtlas atlas) {
        this.atlas = atlas;
        this.shaderProgram = new ShaderProgram("/shaders/chunk.vert", "/shaders/chunk.frag");
    }

    public void render(World world, Camera camera) {
        shaderProgram.bind();
        shaderProgram.setUniform("uProjection", camera.projection());
        shaderProgram.setUniform("uView", camera.view());
        shaderProgram.setUniform("uCameraPosition", camera.position());
        shaderProgram.setUniform("uAtlas", 0);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, atlas.textureId());

        visibleChunks.clear();
        for (World.ChunkHandle handle : world.readyChunkHandles()) {
            if (handle.mesh() == null) {
                continue;
            }

            Chunk chunk = handle.chunk();
            if (!camera.frustum().isBoxVisible(
                    chunk.minWorldX(),
                    0.0f,
                    chunk.minWorldZ(),
                    chunk.minWorldX() + Chunk.SIZE_X,
                    Chunk.SIZE_Y,
                    chunk.minWorldZ() + Chunk.SIZE_Z
            )) {
                continue;
            }

            visibleChunks.add(handle);
        }

        visibleChunks.sort(Comparator.comparingDouble(handle -> distanceSquared(handle.chunk(), camera)));
        for (World.ChunkHandle handle : visibleChunks) {
            handle.mesh().draw();
        }

        world.setVisibleChunkCount(visibleChunks.size());
        world.setDrawnChunkCount(visibleChunks.size());
    }

    @Override
    public void close() {
        shaderProgram.close();
    }

    private double distanceSquared(Chunk chunk, Camera camera) {
        float centerX = chunk.minWorldX() + Chunk.SIZE_X * 0.5f;
        float centerZ = chunk.minWorldZ() + Chunk.SIZE_Z * 0.5f;
        float dx = centerX - camera.position().x;
        float dz = centerZ - camera.position().z;
        return dx * dx + dz * dz;
    }
}
