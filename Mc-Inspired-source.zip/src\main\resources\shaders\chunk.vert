#version 410 core

layout (location = 0) in vec2 aCorner;
layout (location = 1) in vec3 iOrigin;
layout (location = 2) in vec3 iDu;
layout (location = 3) in vec3 iDv;
layout (location = 4) in vec2 iRepeat;
layout (location = 5) in vec4 iRegion;
layout (location = 6) in vec3 iNormal;

uniform mat4 uProjection;
uniform mat4 uView;

out vec2 vTileUv;
out vec2 vRegionMin;
out vec2 vRegionMax;
out vec3 vNormal;
out vec3 vWorldPosition;

void main() {
    vec3 worldPosition = iOrigin + iDu * aCorner.x + iDv * aCorner.y;
    vTileUv = aCorner * iRepeat;
    vRegionMin = iRegion.xy;
    vRegionMax = iRegion.zw;
    vNormal = iNormal;
    vWorldPosition = worldPosition;
    gl_Position = uProjection * uView * vec4(worldPosition, 1.0);
}
