package dev.miyam.voxelsandbox.engine;

public record EngineConfig(
        String title,
        int width,
        int height,
        boolean vSync,
        boolean resizable,
        boolean debugContext
) {
}

