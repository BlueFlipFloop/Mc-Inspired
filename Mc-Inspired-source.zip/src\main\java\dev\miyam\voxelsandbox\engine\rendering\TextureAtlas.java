package dev.miyam.voxelsandbox.engine.rendering;

import dev.miyam.voxelsandbox.engine.assets.TextureLoader;
import org.lwjgl.opengl.GL11;

public final class TextureAtlas implements AutoCloseable {
    private final int textureId;
    private final TextureAtlasLayout layout;

    public TextureAtlas(String resourcePath, int tileWidth, int tileHeight) {
        TextureLoader.TextureData data = TextureLoader.load(resourcePath);
        this.textureId = data.textureId();
        this.layout = new TextureAtlasLayout(data.width(), data.height(), tileWidth, tileHeight);
    }

    public int textureId() {
        return textureId;
    }

    public TextureAtlasLayout layout() {
        return layout;
    }

    @Override
    public void close() {
        GL11.glDeleteTextures(textureId);
    }
}

