package dev.miyam.voxelsandbox.world.generation;

import dev.miyam.voxelsandbox.game.biomes.BiomeProfile;
import dev.miyam.voxelsandbox.game.biomes.BiomeType;
import dev.miyam.voxelsandbox.game.blocks.BlockType;
import dev.miyam.voxelsandbox.world.chunk.Chunk;
import dev.miyam.voxelsandbox.world.chunk.ChunkPos;
import java.util.List;

public final class TerrainGenerator {
    private static final int SEA_LEVEL = 46;
    private static final int TREE_SCAN_RADIUS = 3;
    private static final int MAX_TREE_RADIUS = 2;

    private final int seed;
    private final List<StructureGenerator> structureGenerators;
    private final StructureGenerationContext structureContext;

    private final FastNoiseLite continentalNoise;
    private final FastNoiseLite erosionNoise;
    private final FastNoiseLite ridgeNoise;
    private final FastNoiseLite detailNoise;
    private final FastNoiseLite temperatureNoise;
    private final FastNoiseLite moistureNoise;
    private final FastNoiseLite riverNoise;
    private final FastNoiseLite rareBiomeNoise;
    private final FastNoiseLite caveNoiseA;
    private final FastNoiseLite caveNoiseB;
    private final FastNoiseLite coalOreNoise;
    private final FastNoiseLite ironOreNoise;
    private final FastNoiseLite treeNoise;

    public TerrainGenerator(int seed) {
        this(seed, List.of());
    }

    public TerrainGenerator(int seed, List<StructureGenerator> structureGenerators) {
        this.seed = seed;
        this.structureGenerators = List.copyOf(structureGenerators);
        this.structureContext = new StructureGenerationContext(seed, this);

        continentalNoise = create2DNoise(seed, 0.0014f, 5, 0.5f);
        erosionNoise = create2DNoise(seed ^ 0x51f15e, 0.0024f, 4, 0.55f);
        ridgeNoise = create2DNoise(seed ^ 0x7f4a7c15, 0.0032f, 4, 0.55f);
        detailNoise = create2DNoise(seed ^ 0x5f3759df, 0.012f, 3, 0.45f);
        temperatureNoise = create2DNoise(seed ^ 0x13af91, 0.0018f, 3, 0.5f);
        moistureNoise = create2DNoise(seed ^ 0x734fab, 0.0021f, 3, 0.5f);
        riverNoise = create2DNoise(seed ^ 0x41891d, 0.0045f, 5, 0.55f);
        rareBiomeNoise = create2DNoise(seed ^ 0x992fa1, 0.0009f, 2, 0.5f);
        caveNoiseA = create3DNoise(seed ^ 0x771fe1, 0.036f, 3, 0.55f);
        caveNoiseB = create3DNoise(seed ^ 0x2468ace, 0.018f, 3, 0.5f);
        coalOreNoise = create3DNoise(seed ^ 0x1100aa, 0.082f, 2, 0.5f);
        ironOreNoise = create3DNoise(seed ^ 0x2211bb, 0.074f, 2, 0.5f);
        treeNoise = create2DNoise(seed ^ 0x31f2a5, 0.045f, 2, 0.5f);
    }

    public Chunk generate(ChunkPos position) {
        Chunk chunk = new Chunk(position);
        int baseX = position.minBlockX();
        int baseZ = position.minBlockZ();

        for (int localZ = 0; localZ < Chunk.SIZE_Z; localZ++) {
            for (int localX = 0; localX < Chunk.SIZE_X; localX++) {
                int worldX = baseX + localX;
                int worldZ = baseZ + localZ;
                ColumnSample column = sampleColumn(worldX, worldZ);

                for (int y = 0; y < Chunk.SIZE_Y; y++) {
                    chunk.setBlock(localX, y, localZ, sampleColumnBlock(worldX, y, worldZ, column));
                }
            }
        }

        populateTrees(chunk);
        for (StructureGenerator generator : structureGenerators) {
            generator.generate(chunk, position, structureContext);
        }
        return chunk;
    }

    public BlockType sampleBlock(int worldX, int worldY, int worldZ) {
        if (worldY < 0 || worldY >= Chunk.SIZE_Y) {
            return BlockType.AIR;
        }

        ColumnSample column = sampleColumn(worldX, worldZ);
        BlockType treeBlock = sampleTreeBlock(worldX, worldY, worldZ);
        if (treeBlock != BlockType.AIR) {
            return treeBlock;
        }
        return sampleColumnBlock(worldX, worldY, worldZ, column);
    }

    public BiomeType sampleBiome(int worldX, int worldZ) {
        return sampleColumn(worldX, worldZ).biome();
    }

    public int sampleSurfaceHeight(int worldX, int worldZ) {
        return sampleColumn(worldX, worldZ).surfaceHeight();
    }

    public int seaLevel() {
        return SEA_LEVEL;
    }

    private BlockType sampleColumnBlock(int worldX, int worldY, int worldZ, ColumnSample column) {
        if (worldY > column.surfaceHeight()) {
            return worldY <= SEA_LEVEL ? BlockType.WATER : BlockType.AIR;
        }

        if (isCarvedCave(worldX, worldY, worldZ, column)) {
            return worldY <= SEA_LEVEL - 2 ? BlockType.WATER : BlockType.AIR;
        }

        if (worldY == column.surfaceHeight()) {
            return column.surfaceBlock();
        }
        if (worldY >= column.fillerFloor()) {
            return column.fillerBlock();
        }

        BlockType ore = sampleOre(worldX, worldY, worldZ);
        return ore != null ? ore : BlockType.STONE;
    }

    private ColumnSample sampleColumn(int worldX, int worldZ) {
        float continental = continentalNoise.GetNoise(worldX, worldZ);
        float erosion = erosionNoise.GetNoise(worldX, worldZ);
        float detail = detailNoise.GetNoise(worldX, worldZ);
        float temperature = temperatureNoise.GetNoise(worldX, worldZ);
        float moisture = moistureNoise.GetNoise(worldX, worldZ);
        float ridged = 1.0f - Math.abs(ridgeNoise.GetNoise(worldX, worldZ));
        ridged *= ridged;
        float riverSignal = 1.0f - Math.min(1.0f, Math.abs(riverNoise.GetNoise(worldX, worldZ)) * 6.5f);
        float rareSignal = rareBiomeNoise.GetNoise(worldX, worldZ);

        BiomeType biome = resolveBiome(continental, temperature, moisture, ridged, riverSignal, rareSignal);
        BiomeProfile profile = biome.profile();

        float continentalLift = smoothStep(-0.85f, 0.55f, continental) * 22.0f - 8.0f;
        float mountainLift = ridged * 34.0f * profile.mountainScale() * Math.max(0.0f, continental + 0.35f);
        float terrain = profile.baseHeight()
                + continentalLift
                + erosion * profile.heightVariation()
                + detail * 5.5f
                + mountainLift;

        terrain -= riverSignal * 12.0f * profile.riverCarve();

        if (biome == BiomeType.OCEAN) {
            terrain = Math.min(terrain, SEA_LEVEL - 8.0f + detail * 2.0f);
        } else if (biome == BiomeType.RIVER) {
            terrain = Math.min(terrain, SEA_LEVEL - 2.0f + detail * 1.5f);
        }

        int surfaceHeight = clamp(Math.round(terrain), 6, Chunk.SIZE_Y - 8);
        int fillerFloor = Math.max(1, surfaceHeight - Math.round(profile.dirtDepth()));
        BlockType surfaceBlock = surfaceHeight <= SEA_LEVEL && biome != BiomeType.MOUNTAINS
                ? profile.shoreBlock()
                : profile.topBlock();
        return new ColumnSample(biome, surfaceHeight, fillerFloor, surfaceBlock, profile.fillerBlock(), riverSignal);
    }

    private BiomeType resolveBiome(
            float continental,
            float temperature,
            float moisture,
            float ridged,
            float riverSignal,
            float rareSignal
    ) {
        if (continental < -0.46f) {
            return BiomeType.OCEAN;
        }
        if (riverSignal > 0.82f && continental > -0.25f) {
            return BiomeType.RIVER;
        }
        if (rareSignal > 0.72f && moisture > 0.18f && continental > -0.12f) {
            return BiomeType.BLOSSOM_GROVE;
        }
        if (continental > 0.16f && ridged > 0.42f) {
            return BiomeType.MOUNTAINS;
        }
        if (temperature > 0.32f && moisture < -0.08f) {
            return BiomeType.DESERT;
        }
        if (moisture > 0.14f) {
            return BiomeType.FOREST;
        }
        return BiomeType.PLAINS;
    }

    private boolean isCarvedCave(int worldX, int worldY, int worldZ, ColumnSample column) {
        if (worldY < 8 || worldY >= column.surfaceHeight() - 4) {
            return false;
        }

        float primary = Math.abs(caveNoiseA.GetNoise(worldX, worldY, worldZ));
        float secondary = caveNoiseB.GetNoise(worldX * 1.3f, worldY * 0.9f, worldZ * 1.3f);
        float depthFactor = 1.0f - Math.abs(worldY - 28.0f) / 36.0f;
        float threshold = 0.085f + Math.max(0.0f, depthFactor) * 0.045f;
        return primary < threshold && secondary > -0.18f;
    }

    private BlockType sampleOre(int worldX, int worldY, int worldZ) {
        if (worldY >= 8 && worldY <= 62) {
            float coal = coalOreNoise.GetNoise(worldX, worldY, worldZ);
            if (coal > 0.58f && coal + normalizedDepth(worldY, 62.0f) * 0.12f > 0.63f) {
                return BlockType.COAL_ORE;
            }
        }
        if (worldY >= 6 && worldY <= 46) {
            float iron = ironOreNoise.GetNoise(worldX, worldY, worldZ);
            if (iron > 0.62f && iron + normalizedDepth(worldY, 46.0f) * 0.18f > 0.69f) {
                return BlockType.IRON_ORE;
            }
        }
        return null;
    }

    private void populateTrees(Chunk chunk) {
        int minX = chunk.minWorldX();
        int minZ = chunk.minWorldZ();
        for (int rootZ = minZ - TREE_SCAN_RADIUS; rootZ < minZ + Chunk.SIZE_Z + TREE_SCAN_RADIUS; rootZ++) {
            for (int rootX = minX - TREE_SCAN_RADIUS; rootX < minX + Chunk.SIZE_X + TREE_SCAN_RADIUS; rootX++) {
                TreePlacement tree = sampleTreePlacement(rootX, rootZ);
                if (tree == null) {
                    continue;
                }
                writeTree(chunk, tree);
            }
        }
    }

    private BlockType sampleTreeBlock(int worldX, int worldY, int worldZ) {
        for (int rootZ = worldZ - TREE_SCAN_RADIUS; rootZ <= worldZ + TREE_SCAN_RADIUS; rootZ++) {
            for (int rootX = worldX - TREE_SCAN_RADIUS; rootX <= worldX + TREE_SCAN_RADIUS; rootX++) {
                TreePlacement tree = sampleTreePlacement(rootX, rootZ);
                if (tree == null) {
                    continue;
                }
                BlockType block = blockForTree(tree, worldX, worldY, worldZ);
                if (block != BlockType.AIR) {
                    return block;
                }
            }
        }
        return BlockType.AIR;
    }

    private TreePlacement sampleTreePlacement(int rootX, int rootZ) {
        ColumnSample column = sampleColumn(rootX, rootZ);
        BiomeProfile profile = column.biome().profile();
        if (profile.treeDensity() <= 0.0f || column.surfaceHeight() <= SEA_LEVEL + 1) {
            return null;
        }

        BlockType surface = sampleColumnBlock(rootX, column.surfaceHeight(), rootZ, column);
        if (surface != profile.topBlock() && surface != BlockType.GRASS && surface != BlockType.LUSH_GRASS) {
            return null;
        }

        float treeField = treeNoise.GetNoise(rootX, rootZ) * 0.65f + hashUnit(rootX, rootZ) * 0.35f;
        if (treeField < profile.treeThreshold()) {
            return null;
        }

        int height = 4 + (int) Math.floor(hashUnit(rootX + 17, rootZ - 11) * 3.0f);
        int canopyRadius = profile.rare() ? 3 : (column.biome() == BiomeType.FOREST ? 2 : 2);
        return new TreePlacement(rootX, column.surfaceHeight() + 1, rootZ, height, canopyRadius);
    }

    private void writeTree(Chunk chunk, TreePlacement tree) {
        int canopyBase = tree.rootY() + tree.height() - 2;
        int canopyTop = tree.rootY() + tree.height() + 1;

        for (int y = tree.rootY(); y < tree.rootY() + tree.height(); y++) {
            setChunkBlock(chunk, tree.rootX(), y, tree.rootZ(), BlockType.LOG);
        }

        for (int y = canopyBase; y <= canopyTop; y++) {
            int vertical = Math.abs(y - (tree.rootY() + tree.height() - 1));
            int radius = Math.max(1, tree.canopyRadius() - vertical / 2);
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dx = -radius; dx <= radius; dx++) {
                    if (dx * dx + dz * dz > radius * radius + 1) {
                        continue;
                    }
                    if (dx == 0 && dz == 0 && y < canopyTop) {
                        continue;
                    }
                    setLeafBlock(chunk, tree.rootX() + dx, y, tree.rootZ() + dz);
                }
            }
        }
    }

    private BlockType blockForTree(TreePlacement tree, int worldX, int worldY, int worldZ) {
        if (worldX == tree.rootX() && worldZ == tree.rootZ()
                && worldY >= tree.rootY() && worldY < tree.rootY() + tree.height()) {
            return BlockType.LOG;
        }

        int canopyBase = tree.rootY() + tree.height() - 2;
        int canopyTop = tree.rootY() + tree.height() + 1;
        if (worldY < canopyBase || worldY > canopyTop) {
            return BlockType.AIR;
        }

        int vertical = Math.abs(worldY - (tree.rootY() + tree.height() - 1));
        int radius = Math.max(1, tree.canopyRadius() - vertical / 2);
        int dx = worldX - tree.rootX();
        int dz = worldZ - tree.rootZ();
        if (dx == 0 && dz == 0 && worldY < canopyTop) {
            return BlockType.AIR;
        }
        if (dx * dx + dz * dz <= radius * radius + 1) {
            return BlockType.LEAVES;
        }
        return BlockType.AIR;
    }

    private void setChunkBlock(Chunk chunk, int worldX, int worldY, int worldZ, BlockType block) {
        int localX = worldX - chunk.minWorldX();
        int localZ = worldZ - chunk.minWorldZ();
        if (localX < 0 || localZ < 0 || localX >= Chunk.SIZE_X || localZ >= Chunk.SIZE_Z || worldY < 0 || worldY >= Chunk.SIZE_Y) {
            return;
        }
        chunk.setBlock(localX, worldY, localZ, block);
    }

    private void setLeafBlock(Chunk chunk, int worldX, int worldY, int worldZ) {
        if (sampleColumnBlock(worldX, worldY, worldZ, sampleColumn(worldX, worldZ)) != BlockType.AIR) {
            return;
        }
        setChunkBlock(chunk, worldX, worldY, worldZ, BlockType.LEAVES);
    }

    private FastNoiseLite create2DNoise(int noiseSeed, float frequency, int octaves, float gain) {
        FastNoiseLite noise = new FastNoiseLite(noiseSeed);
        noise.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
        noise.SetFrequency(frequency);
        noise.SetFractalType(FastNoiseLite.FractalType.FBm);
        noise.SetFractalOctaves(octaves);
        noise.SetFractalGain(gain);
        return noise;
    }

    private FastNoiseLite create3DNoise(int noiseSeed, float frequency, int octaves, float gain) {
        return create2DNoise(noiseSeed, frequency, octaves, gain);
    }

    private float normalizedDepth(int y, float ceiling) {
        return 1.0f - y / ceiling;
    }

    private float hashUnit(int x, int z) {
        int hash = seed;
        hash ^= x * 0x27d4eb2d;
        hash = Integer.rotateLeft(hash, 15);
        hash ^= z * 0x165667b1;
        hash *= 0x85ebca6b;
        return (hash & 0x7fffffff) / (float) Integer.MAX_VALUE;
    }

    private float smoothStep(float edge0, float edge1, float value) {
        float t = clamp01((value - edge0) / (edge1 - edge0));
        return t * t * (3.0f - 2.0f * t);
    }

    private float clamp01(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private record ColumnSample(
            BiomeType biome,
            int surfaceHeight,
            int fillerFloor,
            BlockType surfaceBlock,
            BlockType fillerBlock,
            float riverSignal
    ) {
    }

    private record TreePlacement(int rootX, int rootY, int rootZ, int height, int canopyRadius) {
    }
}
