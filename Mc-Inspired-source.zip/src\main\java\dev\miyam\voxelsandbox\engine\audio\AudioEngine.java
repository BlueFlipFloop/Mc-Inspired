package dev.miyam.voxelsandbox.engine.audio;

import org.lwjgl.openal.AL;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.ALCCapabilities;

import static org.lwjgl.openal.ALC10.*;

public final class AudioEngine implements AutoCloseable {
    private long device;
    private long context;

    public void initialize() {
        device = alcOpenDevice((String) null);
        if (device == 0L) {
            throw new IllegalStateException("Unable to open default audio device");
        }

        ALCCapabilities capabilities = ALC.createCapabilities(device);
        context = alcCreateContext(device, (int[]) null);
        if (context == 0L) {
            throw new IllegalStateException("Unable to create OpenAL context");
        }

        alcMakeContextCurrent(context);
        AL.createCapabilities(capabilities);
    }

    @Override
    public void close() {
        if (context != 0L) {
            alcDestroyContext(context);
            context = 0L;
        }
        if (device != 0L) {
            alcCloseDevice(device);
            device = 0L;
        }
    }
}

