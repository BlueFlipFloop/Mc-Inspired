# Voxel Sandbox Architecture

## Foundation Decisions

This project is intentionally starting as a single Gradle application module with strict package boundaries instead of multiple subprojects. That keeps the first runnable vertical slice simple while still preserving the separation we will need when we split networking, dedicated server, registries, and mod tooling into their own modules later.

The runtime is organized around four layers:

1. `engine`
   Owns platform, rendering, input, audio, UI, and low-level reusable services.
2. `world`
   Owns chunk storage, terrain generation, meshing, streaming, and persistence.
3. `game`
   Owns gameplay-specific content and the active game layer.
4. `resources`
   Owns shaders and texture assets consumed by engine systems.

## Why This Shape Scales

- `Engine` owns the outer loop and platform lifecycle, so game rules do not leak into GLFW/OpenGL setup.
- `VoxelSandbox` is the current application layer, which means we can later swap in editor, headless server, benchmark, or test harness layers without rewriting engine bootstrap.
- `World` streams chunks asynchronously through a build queue. Generation and meshing already happen off the render thread, which is the critical scaling decision for large worlds.
- `ChunkMesher` is isolated from OpenGL and returns plain instancing data. That keeps meshing testable and ready for future worker-pool upgrades.
- `GpuChunkMesh` is created only on the main thread, keeping OpenGL ownership explicit and safe.
- `TextureAtlasLayout` is separate from the OpenGL texture handle so background meshing can compute atlas UV regions without touching the GPU.
- `Camera` owns frustum extraction, allowing world culling to remain render-driven instead of entangled with chunk storage.

## Current Implemented Systems

- Java 21 toolchain build via Gradle
- LWJGL 3 bindings for GLFW, OpenGL, STB, and OpenAL
- Core profile OpenGL 4.1 window creation
- Fixed-step update loop with uncapped render interpolation
- Raw mouse first-person fly controller
- Shader compilation and uniform management
- Texture loading through STB
- Texture atlas support with repeated UVs on greedy-meshed quads
- Instanced greedy-quad rendering for chunk surfaces
- Player AABB physics with gravity, jumping, crouching, sprinting, and voxel collision resolution
- Localized chunk-aware collision queries through a reusable voxel collision interface
- Chunk data model
- Procedural terrain generation with layered FastNoiseLite sampling
- Multiple biome classes: oceans, rivers, plains, forests, deserts, mountains, and a rare blossom grove biome
- Cave carving, ore distribution, and deterministic tree placement
- Structure generation hook interface for later dungeons, ruins, and villages
- Greedy meshing with neighbor-aware face culling across chunk borders
- Priority-based background chunk rebuild queue
- Bounded GPU upload budget per frame for stable streaming
- Frustum culling
- On-screen debug overlay

## Near-Term Next Steps

1. Split terrain and feature generation into dedicated biome, cave, ore, tree, and structure pipeline classes as the world ruleset grows.
2. Split chunk data into vertical sections so world height can grow without exploding mesh rebuild cost.
3. Add block raycasting and interaction.
4. Add localized mesh rebuild invalidation for block edits and lighting changes.
5. Introduce registries and data-driven block definitions before item/crafting growth starts.
