package dev.miyam.voxelsandbox.engine.assets;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import org.lwjgl.BufferUtils;

public final class ResourceLoader {
    private ResourceLoader() {
    }

    public static ByteBuffer loadResource(String path) {
        try (InputStream stream = ResourceLoader.class.getResourceAsStream(path)) {
            if (stream == null) {
                throw new IllegalArgumentException("Missing resource: " + path);
            }
            byte[] bytes = stream.readAllBytes();
            ByteBuffer buffer = BufferUtils.createByteBuffer(bytes.length);
            buffer.put(bytes);
            buffer.flip();
            return buffer;
        } catch (IOException exception) {
            throw new IllegalStateException("Unable to load resource: " + path, exception);
        }
    }

    public static String loadString(String path) {
        ByteBuffer buffer = loadResource(path);
        byte[] bytes = new byte[buffer.remaining()];
        buffer.get(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}

