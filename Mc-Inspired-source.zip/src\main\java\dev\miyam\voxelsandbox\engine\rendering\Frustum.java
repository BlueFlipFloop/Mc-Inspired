package dev.miyam.voxelsandbox.engine.rendering;

import org.joml.Matrix4fc;
import org.joml.Vector4f;

public final class Frustum {
    private final Vector4f[] planes = {
            new Vector4f(),
            new Vector4f(),
            new Vector4f(),
            new Vector4f(),
            new Vector4f(),
            new Vector4f()
    };

    public void update(Matrix4fc matrix) {
        planes[0].set(matrix.m03() + matrix.m00(), matrix.m13() + matrix.m10(), matrix.m23() + matrix.m20(), matrix.m33() + matrix.m30());
        planes[1].set(matrix.m03() - matrix.m00(), matrix.m13() - matrix.m10(), matrix.m23() - matrix.m20(), matrix.m33() - matrix.m30());
        planes[2].set(matrix.m03() + matrix.m01(), matrix.m13() + matrix.m11(), matrix.m23() + matrix.m21(), matrix.m33() + matrix.m31());
        planes[3].set(matrix.m03() - matrix.m01(), matrix.m13() - matrix.m11(), matrix.m23() - matrix.m21(), matrix.m33() - matrix.m31());
        planes[4].set(matrix.m03() + matrix.m02(), matrix.m13() + matrix.m12(), matrix.m23() + matrix.m22(), matrix.m33() + matrix.m32());
        planes[5].set(matrix.m03() - matrix.m02(), matrix.m13() - matrix.m12(), matrix.m23() - matrix.m22(), matrix.m33() - matrix.m32());

        for (Vector4f plane : planes) {
            float inverseLength = 1.0f / (float) Math.sqrt(plane.x * plane.x + plane.y * plane.y + plane.z * plane.z);
            plane.mul(inverseLength);
        }
    }

    public boolean isBoxVisible(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        for (Vector4f plane : planes) {
            float x = plane.x >= 0.0f ? maxX : minX;
            float y = plane.y >= 0.0f ? maxY : minY;
            float z = plane.z >= 0.0f ? maxZ : minZ;
            if (plane.x * x + plane.y * y + plane.z * z + plane.w < 0.0f) {
                return false;
            }
        }
        return true;
    }
}
