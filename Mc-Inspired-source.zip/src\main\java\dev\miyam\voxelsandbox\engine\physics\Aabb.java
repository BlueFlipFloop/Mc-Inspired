package dev.miyam.voxelsandbox.engine.physics;

public final class Aabb {
    private float minX;
    private float minY;
    private float minZ;
    private float maxX;
    private float maxY;
    private float maxZ;

    public Aabb setFromFootPosition(float x, float y, float z, float halfWidth, float height) {
        minX = x - halfWidth;
        minY = y;
        minZ = z - halfWidth;
        maxX = x + halfWidth;
        maxY = y + height;
        maxZ = z + halfWidth;
        return this;
    }

    public Aabb set(Aabb other) {
        minX = other.minX;
        minY = other.minY;
        minZ = other.minZ;
        maxX = other.maxX;
        maxY = other.maxY;
        maxZ = other.maxZ;
        return this;
    }

    public Aabb setMinMax(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
        this.minX = minX;
        this.minY = minY;
        this.minZ = minZ;
        this.maxX = maxX;
        this.maxY = maxY;
        this.maxZ = maxZ;
        return this;
    }

    public Aabb translate(float dx, float dy, float dz) {
        minX += dx;
        maxX += dx;
        minY += dy;
        maxY += dy;
        minZ += dz;
        maxZ += dz;
        return this;
    }

    public float minX() {
        return minX;
    }

    public float minY() {
        return minY;
    }

    public float minZ() {
        return minZ;
    }

    public float maxX() {
        return maxX;
    }

    public float maxY() {
        return maxY;
    }

    public float maxZ() {
        return maxZ;
    }
}
