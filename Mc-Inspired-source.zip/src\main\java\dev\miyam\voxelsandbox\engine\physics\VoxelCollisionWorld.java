package dev.miyam.voxelsandbox.engine.physics;

import dev.miyam.voxelsandbox.game.blocks.BlockType;

public interface VoxelCollisionWorld {
    BlockType blockAt(int worldX, int worldY, int worldZ);

    default boolean isBlockCollidable(int worldX, int worldY, int worldZ) {
        return blockAt(worldX, worldY, worldZ).collidable();
    }

    int surfaceHeightAt(int worldX, int worldZ);
}

