package dev.miyam.voxelsandbox.engine.rendering;

import dev.miyam.voxelsandbox.engine.physics.Aabb;
import dev.miyam.voxelsandbox.engine.shaders.ShaderProgram;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class DebugAabbRenderer implements AutoCloseable {
    private static final int VERTEX_COMPONENTS = 3;

    private final ShaderProgram shaderProgram = new ShaderProgram("/shaders/debug_line.vert", "/shaders/debug_line.frag");
    private final int vao;
    private final int vbo;
    private final Vector3f color = new Vector3f(0.98f, 0.42f, 0.22f);

    public DebugAabbRenderer() {
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL20.glVertexAttribPointer(0, VERTEX_COMPONENTS, GL11.GL_FLOAT, false, VERTEX_COMPONENTS * Float.BYTES, 0L);
        GL20.glEnableVertexAttribArray(0);
        GL30.glBindVertexArray(0);
    }

    public void render(Camera camera, Aabb bounds) {
        render(camera, bounds, color);
    }

    public void render(Camera camera, Aabb bounds, Vector3f lineColor) {
        float[] vertices = buildWireframe(bounds);

        shaderProgram.bind();
        shaderProgram.setUniform("uProjection", camera.projection());
        shaderProgram.setUniform("uView", camera.view());
        shaderProgram.setUniform("uColor", lineColor);

        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, vertices, GL15.GL_DYNAMIC_DRAW);
        GL11.glDrawArrays(GL11.GL_LINES, 0, vertices.length / VERTEX_COMPONENTS);
        GL30.glBindVertexArray(0);
    }

    @Override
    public void close() {
        shaderProgram.close();
        GL30.glDeleteVertexArrays(vao);
        GL15.glDeleteBuffers(vbo);
    }

    private float[] buildWireframe(Aabb bounds) {
        float minX = bounds.minX();
        float minY = bounds.minY();
        float minZ = bounds.minZ();
        float maxX = bounds.maxX();
        float maxY = bounds.maxY();
        float maxZ = bounds.maxZ();

        return new float[]{
                minX, minY, minZ, maxX, minY, minZ,
                maxX, minY, minZ, maxX, minY, maxZ,
                maxX, minY, maxZ, minX, minY, maxZ,
                minX, minY, maxZ, minX, minY, minZ,

                minX, maxY, minZ, maxX, maxY, minZ,
                maxX, maxY, minZ, maxX, maxY, maxZ,
                maxX, maxY, maxZ, minX, maxY, maxZ,
                minX, maxY, maxZ, minX, maxY, minZ,

                minX, minY, minZ, minX, maxY, minZ,
                maxX, minY, minZ, maxX, maxY, minZ,
                maxX, minY, maxZ, maxX, maxY, maxZ,
                minX, minY, maxZ, minX, maxY, maxZ
        };
    }
}
