package dev.miyam.voxelsandbox.engine.physics;

public final class VoxelCollisionResolver {
    private static final float EPSILON = 0.0001f;

    private final VoxelCollisionWorld world;

    public VoxelCollisionResolver(VoxelCollisionWorld world) {
        this.world = world;
    }

    public boolean canOccupy(Aabb bounds) {
        int minX = floor(bounds.minX() + EPSILON);
        int maxX = floor(bounds.maxX() - EPSILON);
        int minY = floor(bounds.minY() + EPSILON);
        int maxY = floor(bounds.maxY() - EPSILON);
        int minZ = floor(bounds.minZ() + EPSILON);
        int maxZ = floor(bounds.maxZ() - EPSILON);

        for (int y = minY; y <= maxY; y++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX; x <= maxX; x++) {
                    if (world.isBlockCollidable(x, y, z)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public float moveX(Aabb bounds, float deltaX) {
        if (deltaX == 0.0f) {
            return 0.0f;
        }

        int minY = floor(bounds.minY() + EPSILON);
        int maxY = floor(bounds.maxY() - EPSILON);
        int minZ = floor(bounds.minZ() + EPSILON);
        int maxZ = floor(bounds.maxZ() - EPSILON);

        if (deltaX > 0.0f) {
            int startX = floor(bounds.maxX() - EPSILON) + 1;
            int endX = floor(bounds.maxX() + deltaX - EPSILON);
            for (int x = startX; x <= endX; x++) {
                for (int y = minY; y <= maxY; y++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = x - bounds.maxX() - EPSILON;
                            if (candidate < deltaX) {
                                deltaX = candidate;
                            }
                        }
                    }
                }
            }
        } else {
            int startX = floor(bounds.minX() + EPSILON) - 1;
            int endX = floor(bounds.minX() + deltaX + EPSILON);
            for (int x = startX; x >= endX; x--) {
                for (int y = minY; y <= maxY; y++) {
                    for (int z = minZ; z <= maxZ; z++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = (x + 1) - bounds.minX() + EPSILON;
                            if (candidate > deltaX) {
                                deltaX = candidate;
                            }
                        }
                    }
                }
            }
        }
        return deltaX;
    }

    public float moveY(Aabb bounds, float deltaY) {
        if (deltaY == 0.0f) {
            return 0.0f;
        }

        int minX = floor(bounds.minX() + EPSILON);
        int maxX = floor(bounds.maxX() - EPSILON);
        int minZ = floor(bounds.minZ() + EPSILON);
        int maxZ = floor(bounds.maxZ() - EPSILON);

        if (deltaY > 0.0f) {
            int startY = floor(bounds.maxY() - EPSILON) + 1;
            int endY = floor(bounds.maxY() + deltaY - EPSILON);
            for (int y = startY; y <= endY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = y - bounds.maxY() - EPSILON;
                            if (candidate < deltaY) {
                                deltaY = candidate;
                            }
                        }
                    }
                }
            }
        } else {
            int startY = floor(bounds.minY() + EPSILON) - 1;
            int endY = floor(bounds.minY() + deltaY + EPSILON);
            for (int y = startY; y >= endY; y--) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = (y + 1) - bounds.minY() + EPSILON;
                            if (candidate > deltaY) {
                                deltaY = candidate;
                            }
                        }
                    }
                }
            }
        }
        return deltaY;
    }

    public float moveZ(Aabb bounds, float deltaZ) {
        if (deltaZ == 0.0f) {
            return 0.0f;
        }

        int minX = floor(bounds.minX() + EPSILON);
        int maxX = floor(bounds.maxX() - EPSILON);
        int minY = floor(bounds.minY() + EPSILON);
        int maxY = floor(bounds.maxY() - EPSILON);

        if (deltaZ > 0.0f) {
            int startZ = floor(bounds.maxZ() - EPSILON) + 1;
            int endZ = floor(bounds.maxZ() + deltaZ - EPSILON);
            for (int z = startZ; z <= endZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    for (int x = minX; x <= maxX; x++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = z - bounds.maxZ() - EPSILON;
                            if (candidate < deltaZ) {
                                deltaZ = candidate;
                            }
                        }
                    }
                }
            }
        } else {
            int startZ = floor(bounds.minZ() + EPSILON) - 1;
            int endZ = floor(bounds.minZ() + deltaZ + EPSILON);
            for (int z = startZ; z >= endZ; z--) {
                for (int y = minY; y <= maxY; y++) {
                    for (int x = minX; x <= maxX; x++) {
                        if (world.isBlockCollidable(x, y, z)) {
                            float candidate = (z + 1) - bounds.minZ() + EPSILON;
                            if (candidate > deltaZ) {
                                deltaZ = candidate;
                            }
                        }
                    }
                }
            }
        }
        return deltaZ;
    }

    private int floor(float value) {
        return (int) Math.floor(value);
    }
}
