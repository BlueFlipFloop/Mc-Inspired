/**
 * Crafting recipes and runtime crafting pipelines land here in Phase 3.
 */
package dev.miyam.voxelsandbox.game.crafting;

