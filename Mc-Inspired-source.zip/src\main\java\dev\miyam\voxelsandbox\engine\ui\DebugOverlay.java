package dev.miyam.voxelsandbox.engine.ui;

import dev.miyam.voxelsandbox.engine.Window;
import dev.miyam.voxelsandbox.engine.rendering.Camera;
import dev.miyam.voxelsandbox.game.entities.Player;
import dev.miyam.voxelsandbox.world.terrain.World;
import java.util.List;

public final class DebugOverlay implements AutoCloseable {
    private final TextRenderer textRenderer = new TextRenderer();

    public void render(Window window, Player player, Camera camera, World world, int fps, double frameMillis) {
        List<String> lines = List.of(
                "FPS: " + fps,
                "FRAME: " + String.format("%.2f", frameMillis) + " MS",
                "POS: " + format(player.position().x) + ", " + format(player.position().y) + ", " + format(player.position().z),
                "VEL: " + format(player.velocity().x) + ", " + format(player.velocity().y) + ", " + format(player.velocity().z),
                "PITCH/YAW: " + format(camera.pitch()) + ", " + format(camera.yaw()),
                "GROUNDED: " + (player.grounded() ? "YES" : "NO"),
                "FALL: " + format(player.fallDistance()) + " / " + format(player.lastLandingSpeed()),
                "CHUNKS: " + world.loadedChunkCount(),
                "VISIBLE: " + world.visibleChunkCount(),
                "DRAWN: " + world.drawnChunkCount(),
                "PENDING: " + world.pendingChunkCount(),
                "UPLOADS: " + world.lastUploadCount()
        );
        textRenderer.drawLines(lines, 12.0f, 12.0f, 2.0f, window.getWidth(), window.getHeight());
    }

    @Override
    public void close() {
        textRenderer.close();
    }

    private String format(float value) {
        return String.format("%.2f", value);
    }
}
