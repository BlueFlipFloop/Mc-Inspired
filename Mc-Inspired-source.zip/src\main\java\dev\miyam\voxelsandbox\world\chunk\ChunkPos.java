package dev.miyam.voxelsandbox.world.chunk;

public record ChunkPos(int x, int z) {
    public int minBlockX() {
        return x * Chunk.SIZE_X;
    }

    public int minBlockZ() {
        return z * Chunk.SIZE_Z;
    }
}

