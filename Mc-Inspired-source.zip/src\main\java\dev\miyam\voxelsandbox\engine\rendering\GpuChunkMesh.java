package dev.miyam.voxelsandbox.engine.rendering;

import dev.miyam.voxelsandbox.world.chunk.ChunkMesher;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL33;

public final class GpuChunkMesh implements AutoCloseable {
    private static int sharedQuadVao;
    private static int sharedQuadVbo;
    private static int sharedQuadEbo;

    private final int vao;
    private final int instanceVbo;
    private final int instanceCount;

    public GpuChunkMesh(float[] instances, int instanceCount) {
        ensureSharedQuad();
        this.instanceCount = instanceCount;
        this.vao = GL30.glGenVertexArrays();
        this.instanceVbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(vao);

        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, sharedQuadVbo);
        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 2 * Float.BYTES, 0L);
        GL20.glEnableVertexAttribArray(0);

        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, sharedQuadEbo);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, instanceVbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, instances, GL15.GL_STATIC_DRAW);

        int stride = ChunkMesher.INSTANCE_STRIDE_FLOATS * Float.BYTES;
        setInstanceAttribute(1, 3, stride, 0L);
        setInstanceAttribute(2, 3, stride, 3L * Float.BYTES);
        setInstanceAttribute(3, 3, stride, 6L * Float.BYTES);
        setInstanceAttribute(4, 2, stride, 9L * Float.BYTES);
        setInstanceAttribute(5, 4, stride, 11L * Float.BYTES);
        setInstanceAttribute(6, 3, stride, 15L * Float.BYTES);

        GL30.glBindVertexArray(0);
    }

    public void draw() {
        GL30.glBindVertexArray(vao);
        GL31.glDrawElementsInstanced(GL11.GL_TRIANGLES, 6, GL11.GL_UNSIGNED_INT, 0L, instanceCount);
    }

    public int instanceCount() {
        return instanceCount;
    }

    @Override
    public void close() {
        GL30.glDeleteVertexArrays(vao);
        GL15.glDeleteBuffers(instanceVbo);
    }

    private void setInstanceAttribute(int index, int componentCount, int stride, long offset) {
        GL20.glVertexAttribPointer(index, componentCount, GL11.GL_FLOAT, false, stride, offset);
        GL20.glEnableVertexAttribArray(index);
        GL33.glVertexAttribDivisor(index, 1);
    }

    private static void ensureSharedQuad() {
        if (sharedQuadVao != 0) {
            return;
        }

        float[] quadVertices = {
                0.0f, 0.0f,
                1.0f, 0.0f,
                1.0f, 1.0f,
                0.0f, 1.0f
        };
        int[] quadIndices = {0, 1, 2, 0, 2, 3};

        sharedQuadVao = GL30.glGenVertexArrays();
        sharedQuadVbo = GL15.glGenBuffers();
        sharedQuadEbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(sharedQuadVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, sharedQuadVbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, quadVertices, GL15.GL_STATIC_DRAW);
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, sharedQuadEbo);
        GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, quadIndices, GL15.GL_STATIC_DRAW);
        GL30.glBindVertexArray(0);
    }
}
