package dev.miyam.voxelsandbox.engine.rendering;

public record AtlasRegion(float minU, float minV, float maxU, float maxV) {
}

