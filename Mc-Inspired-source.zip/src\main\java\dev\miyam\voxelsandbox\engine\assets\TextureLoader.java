package dev.miyam.voxelsandbox.engine.assets;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL30;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;

public final class TextureLoader {
    private TextureLoader() {
    }

    public static TextureData load(String resourcePath) {
        ByteBuffer encoded = ResourceLoader.loadResource(resourcePath);
        STBImage.stbi_set_flip_vertically_on_load(false);

        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer width = stack.mallocInt(1);
            IntBuffer height = stack.mallocInt(1);
            IntBuffer channels = stack.mallocInt(1);

            ByteBuffer pixels = STBImage.stbi_load_from_memory(encoded, width, height, channels, 4);
            boolean stbAllocated = pixels != null;
            if (pixels == null) {
                DecodedTexture decodedTexture = tryDecodePortablePixmap(encoded, resourcePath);
                if (decodedTexture == null) {
                    throw new IllegalStateException("Unable to decode texture " + resourcePath + ": " + STBImage.stbi_failure_reason());
                }
                pixels = decodedTexture.pixels();
                width.put(0, decodedTexture.width());
                height.put(0, decodedTexture.height());
            }

            int textureId = GL11.glGenTextures();
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
            GL11.glTexImage2D(
                    GL11.GL_TEXTURE_2D,
                    0,
                    GL11.GL_RGBA8,
                    width.get(0),
                    height.get(0),
                    0,
                    GL11.GL_RGBA,
                    GL11.GL_UNSIGNED_BYTE,
                    pixels
            );
            GL30.glGenerateMipmap(GL11.GL_TEXTURE_2D);
            if (stbAllocated) {
                STBImage.stbi_image_free(pixels);
            }

            return new TextureData(textureId, width.get(0), height.get(0));
        }
    }

    private static DecodedTexture tryDecodePortablePixmap(ByteBuffer encoded, String resourcePath) {
        String text = StandardCharsets.US_ASCII.decode(encoded.duplicate()).toString();
        if (!text.startsWith("P3")) {
            return null;
        }

        List<String> tokens = tokenizePpm(text);
        if (tokens.size() < 4 || !"P3".equals(tokens.get(0))) {
            throw new IllegalStateException("Malformed PPM texture: " + resourcePath);
        }

        int width = Integer.parseInt(tokens.get(1));
        int height = Integer.parseInt(tokens.get(2));
        int maxValue = Integer.parseInt(tokens.get(3));
        if (width <= 0 || height <= 0 || maxValue <= 0) {
            throw new IllegalStateException("Invalid PPM header in " + resourcePath);
        }

        int expectedComponents = width * height * 3;
        if (tokens.size() < 4 + expectedComponents) {
            throw new IllegalStateException("PPM texture is truncated: " + resourcePath);
        }

        ByteBuffer pixels = ByteBuffer.allocateDirect(width * height * 4);
        int tokenIndex = 4;
        for (int i = 0; i < width * height; i++) {
            int red = scalePpm(Integer.parseInt(tokens.get(tokenIndex++)), maxValue);
            int green = scalePpm(Integer.parseInt(tokens.get(tokenIndex++)), maxValue);
            int blue = scalePpm(Integer.parseInt(tokens.get(tokenIndex++)), maxValue);
            pixels.put((byte) red);
            pixels.put((byte) green);
            pixels.put((byte) blue);
            pixels.put((byte) 255);
        }
        pixels.flip();
        return new DecodedTexture(pixels, width, height);
    }

    private static List<String> tokenizePpm(String text) {
        List<String> tokens = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inComment = false;

        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            if (inComment) {
                if (character == '\n' || character == '\r') {
                    inComment = false;
                }
                continue;
            }

            if (character == '#') {
                inComment = true;
                if (!current.isEmpty()) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                continue;
            }

            if (Character.isWhitespace(character)) {
                if (!current.isEmpty()) {
                    tokens.add(current.toString());
                    current.setLength(0);
                }
                continue;
            }

            current.append(character);
        }

        if (!current.isEmpty()) {
            tokens.add(current.toString());
        }

        return tokens;
    }

    private static int scalePpm(int component, int maxValue) {
        int clamped = Math.max(0, Math.min(component, maxValue));
        return maxValue == 255 ? clamped : Math.round(clamped * (255.0f / maxValue));
    }

    private record DecodedTexture(ByteBuffer pixels, int width, int height) {
    }

    public record TextureData(int textureId, int width, int height) {
    }
}
