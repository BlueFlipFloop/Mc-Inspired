/**
 * Automation gameplay systems, machine graphs, and power transport belong here.
 */
package dev.miyam.voxelsandbox.game.automation;

