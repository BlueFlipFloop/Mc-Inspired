package dev.miyam.voxelsandbox.game;

import dev.miyam.voxelsandbox.engine.ApplicationLayer;
import dev.miyam.voxelsandbox.engine.EngineContext;
import dev.miyam.voxelsandbox.engine.Window;
import dev.miyam.voxelsandbox.engine.input.FirstPersonController;
import dev.miyam.voxelsandbox.engine.rendering.Camera;
import dev.miyam.voxelsandbox.engine.rendering.DebugAabbRenderer;
import dev.miyam.voxelsandbox.engine.rendering.TextureAtlas;
import dev.miyam.voxelsandbox.engine.rendering.VoxelRenderer;
import dev.miyam.voxelsandbox.engine.ui.DebugOverlay;
import dev.miyam.voxelsandbox.game.blocks.BlockType;
import dev.miyam.voxelsandbox.game.entities.Player;
import dev.miyam.voxelsandbox.world.chunk.ChunkMesher;
import dev.miyam.voxelsandbox.world.generation.TerrainGenerator;
import dev.miyam.voxelsandbox.world.terrain.World;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

public final class VoxelSandbox implements ApplicationLayer {
    private EngineContext context;
    private Camera camera;
    private Player player;
    private FirstPersonController controller;
    private TextureAtlas atlas;
    private VoxelRenderer voxelRenderer;
    private DebugAabbRenderer debugAabbRenderer;
    private DebugOverlay debugOverlay;
    private World world;
    private boolean debugVisible = true;
    private boolean collisionDebugVisible;
    private int fps;
    private int frameCounter;
    private double fpsTimer;
    private double frameMillis;

    @Override
    public void initialize(EngineContext context) {
        this.context = context;

        camera = new Camera(context.window().aspectRatio());
        camera.setFarPlane(640.0f);
        camera.updateProjection(context.window().aspectRatio());
        atlas = new TextureAtlas("/textures/atlas.ppm", 8, 8);
        voxelRenderer = new VoxelRenderer(atlas);
        debugAabbRenderer = new DebugAabbRenderer();
        debugOverlay = new DebugOverlay();
        world = new World(new TerrainGenerator(1337), new ChunkMesher(atlas.layout()), 12);
        player = new Player();
        controller = new FirstPersonController(camera, player, world);

        context.input().setCursorCaptured(true);
        spawnPlayer();
        player.syncCamera(camera, 1.0);
    }

    @Override
    public void update(double deltaTime) {
        if (context.input().wasKeyPressed(GLFW.GLFW_KEY_ESCAPE)) {
            context.window().requestClose();
        }
        if (context.input().wasKeyPressed(GLFW.GLFW_KEY_F3)) {
            debugVisible = !debugVisible;
        }
        if (context.input().wasKeyPressed(GLFW.GLFW_KEY_F4)) {
            collisionDebugVisible = !collisionDebugVisible;
        }

        controller.update(context.input(), deltaTime);
        world.updateStreaming(player.position());
        world.uploadCompletedMeshes();
        updateTiming(deltaTime);
    }

    @Override
    public void render(double alpha) {
        GL11.glClearColor(0.55f, 0.75f, 0.94f, 1.0f);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        player.syncCamera(camera, alpha);
        voxelRenderer.render(world, camera);
        if (collisionDebugVisible) {
            debugAabbRenderer.render(camera, player.collisionBounds());
        }
        if (debugVisible) {
            debugOverlay.render(context.window(), player, camera, world, fps, frameMillis);
        }

        updateWindowTitle(context.window());
    }

    @Override
    public void resize(int width, int height) {
        camera.updateProjection(width / (float) Math.max(height, 1));
    }

    @Override
    public void dispose() {
        if (world != null) {
            world.close();
        }
        if (debugOverlay != null) {
            debugOverlay.close();
        }
        if (debugAabbRenderer != null) {
            debugAabbRenderer.close();
        }
        if (voxelRenderer != null) {
            voxelRenderer.close();
        }
        if (atlas != null) {
            atlas.close();
        }
    }

    private void updateTiming(double deltaTime) {
        frameCounter++;
        fpsTimer += deltaTime;
        frameMillis = deltaTime * 1000.0;
        if (fpsTimer >= 1.0) {
            fps = frameCounter;
            frameCounter = 0;
            fpsTimer = 0.0;
        }
    }

    private void updateWindowTitle(Window window) {
        window.setTitle("Voxel Sandbox | FPS " + fps + " | Chunks " + world.loadedChunkCount() + " (" + world.visibleChunkCount() + " visible)");
    }

    private void spawnPlayer() {
        int spawnX = 0;
        int spawnZ = 0;
        for (int radius = 0; radius <= 48; radius++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dx = -radius; dx <= radius; dx++) {
                    if (Math.abs(dx) != radius && Math.abs(dz) != radius) {
                        continue;
                    }
                    int candidateX = spawnX + dx;
                    int candidateZ = spawnZ + dz;
                    int surfaceY = world.surfaceHeightAt(candidateX, candidateZ);
                    if (world.blockAt(candidateX, surfaceY + 1, candidateZ) != BlockType.AIR) {
                        continue;
                    }
                    if (world.blockAt(candidateX, surfaceY + 2, candidateZ) != BlockType.AIR) {
                        continue;
                    }
                    player.setSpawn(candidateX + 0.5f, surfaceY + 1.0f, candidateZ + 0.5f);
                    player.snapToStandingHeight();
                    return;
                }
            }
        }

        int fallbackSurface = world.surfaceHeightAt(spawnX, spawnZ);
        player.setSpawn(spawnX + 0.5f, fallbackSurface + 2.0f, spawnZ + 0.5f);
        player.snapToStandingHeight();
    }
}
