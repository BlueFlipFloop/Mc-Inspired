@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "LOCAL_JDK_ROOT="

for /d %%D in ("%SCRIPT_DIR%.tools\jdk-*") do (
    set "LOCAL_JDK_ROOT=%%~fD"
)

for /d %%D in ("%SCRIPT_DIR%.tools\OpenJDK*") do (
    set "LOCAL_JDK_ROOT=%%~fD"
)

if "%LOCAL_JDK_ROOT%"=="" (
    echo Local JDK not found under .tools
    exit /b 1
)

set "JAVA_HOME=%LOCAL_JDK_ROOT%"
set "PATH=%JAVA_HOME%\bin;%PATH%"
set "GRADLE_USER_HOME=%SCRIPT_DIR%.gradle-user-home"

call "%SCRIPT_DIR%gradlew.bat" %*

