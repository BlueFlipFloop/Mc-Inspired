package dev.miyam.voxelsandbox.world.chunk;

public record ChunkMeshData(float[] instances, int instanceCount) {
    public boolean isEmpty() {
        return instanceCount == 0;
    }
}

