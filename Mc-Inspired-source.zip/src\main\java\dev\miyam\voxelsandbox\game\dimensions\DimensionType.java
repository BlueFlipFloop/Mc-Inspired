package dev.miyam.voxelsandbox.game.dimensions;

public enum DimensionType {
    OVERWORLD
}

