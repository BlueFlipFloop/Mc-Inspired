package dev.miyam.voxelsandbox.engine.ui;

import dev.miyam.voxelsandbox.engine.shaders.ShaderProgram;
import java.util.ArrayList;
import java.util.List;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class TextRenderer implements AutoCloseable {
    private static final int STRIDE_FLOATS = 8;
    private static final int STRIDE_BYTES = STRIDE_FLOATS * Float.BYTES;

    private final ShaderProgram shaderProgram = new ShaderProgram("/shaders/ui.vert", "/shaders/ui.frag");
    private final BitmapFont font = new BitmapFont();
    private final int vao;
    private final int vbo;
    private final int ebo;

    public TextRenderer() {
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        ebo = GL15.glGenBuffers();

        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ebo);

        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, STRIDE_BYTES, 0L);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, STRIDE_BYTES, 2L * Float.BYTES);
        GL20.glEnableVertexAttribArray(1);
        GL20.glVertexAttribPointer(2, 4, GL11.GL_FLOAT, false, STRIDE_BYTES, 4L * Float.BYTES);
        GL20.glEnableVertexAttribArray(2);

        GL30.glBindVertexArray(0);
    }

    public void drawLines(List<String> lines, float x, float y, float scale, int width, int height) {
        List<Float> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();
        float penY = y;

        for (String line : lines) {
            appendLine(vertices, indices, line, x, penY, scale);
            penY += font.advance() * scale + 4.0f;
        }

        shaderProgram.bind();
        shaderProgram.setUniform("uProjection", new Matrix4f().ortho2D(0.0f, width, height, 0.0f));
        shaderProgram.setUniform("uTexture", 0);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, font.textureId());

        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, toFloatArray(vertices), GL15.GL_DYNAMIC_DRAW);
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ebo);
        GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, toIntArray(indices), GL15.GL_DYNAMIC_DRAW);
        GL11.glDrawElements(GL11.GL_TRIANGLES, indices.size(), GL11.GL_UNSIGNED_INT, 0L);
        GL30.glBindVertexArray(0);
    }

    @Override
    public void close() {
        shaderProgram.close();
        font.close();
        GL30.glDeleteVertexArrays(vao);
        GL15.glDeleteBuffers(vbo);
        GL15.glDeleteBuffers(ebo);
    }

    private void appendLine(List<Float> vertices, List<Integer> indices, String text, float x, float y, float scale) {
        float penX = x;
        for (int i = 0; i < text.length(); i++) {
            char character = text.charAt(i);
            BitmapFont.Glyph glyph = font.glyph(character);

            float width = font.glyphWidth() * scale;
            float height = font.glyphHeight() * scale;
            int baseIndex = vertices.size() / STRIDE_FLOATS;

            appendVertex(vertices, penX, y, glyph.minU(), glyph.minV());
            appendVertex(vertices, penX + width, y, glyph.maxU(), glyph.minV());
            appendVertex(vertices, penX + width, y + height, glyph.maxU(), glyph.maxV());
            appendVertex(vertices, penX, y + height, glyph.minU(), glyph.maxV());

            indices.add(baseIndex);
            indices.add(baseIndex + 1);
            indices.add(baseIndex + 2);
            indices.add(baseIndex);
            indices.add(baseIndex + 2);
            indices.add(baseIndex + 3);

            penX += font.advance() * scale;
        }
    }

    private void appendVertex(List<Float> vertices, float x, float y, float u, float v) {
        vertices.add(x);
        vertices.add(y);
        vertices.add(u);
        vertices.add(v);
        vertices.add(0.93f);
        vertices.add(0.97f);
        vertices.add(0.96f);
        vertices.add(1.0f);
    }

    private float[] toFloatArray(List<Float> source) {
        float[] output = new float[source.size()];
        for (int i = 0; i < source.size(); i++) {
            output[i] = source.get(i);
        }
        return output;
    }

    private int[] toIntArray(List<Integer> source) {
        int[] output = new int[source.size()];
        for (int i = 0; i < source.size(); i++) {
            output[i] = source.get(i);
        }
        return output;
    }
}

