package dev.miyam.voxelsandbox.engine.shaders;

import dev.miyam.voxelsandbox.engine.assets.ResourceLoader;
import org.joml.Matrix4fc;
import org.joml.Vector3fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.system.MemoryStack;

public final class ShaderProgram implements AutoCloseable {
    private final int programId;

    public ShaderProgram(String vertexPath, String fragmentPath) {
        int vertexId = compileShader(GL20.GL_VERTEX_SHADER, ResourceLoader.loadString(vertexPath));
        int fragmentId = compileShader(GL20.GL_FRAGMENT_SHADER, ResourceLoader.loadString(fragmentPath));

        programId = GL20.glCreateProgram();
        GL20.glAttachShader(programId, vertexId);
        GL20.glAttachShader(programId, fragmentId);
        GL20.glLinkProgram(programId);

        if (GL20.glGetProgrami(programId, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            throw new IllegalStateException("Shader link failed: " + GL20.glGetProgramInfoLog(programId));
        }

        GL20.glDetachShader(programId, vertexId);
        GL20.glDetachShader(programId, fragmentId);
        GL20.glDeleteShader(vertexId);
        GL20.glDeleteShader(fragmentId);
    }

    public void bind() {
        GL20.glUseProgram(programId);
    }

    public void setUniform(String name, int value) {
        GL20.glUniform1i(uniformLocation(name), value);
    }

    public void setUniform(String name, Matrix4fc matrix) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            GL20.glUniformMatrix4fv(uniformLocation(name), false, matrix.get(stack.mallocFloat(16)));
        }
    }

    public void setUniform(String name, Vector3fc vector) {
        GL20.glUniform3f(uniformLocation(name), vector.x(), vector.y(), vector.z());
    }

    @Override
    public void close() {
        GL20.glDeleteProgram(programId);
    }

    private int uniformLocation(String name) {
        int location = GL20.glGetUniformLocation(programId, name);
        if (location < 0) {
            throw new IllegalArgumentException("Unknown shader uniform: " + name);
        }
        return location;
    }

    private int compileShader(int type, String source) {
        int shaderId = GL20.glCreateShader(type);
        GL20.glShaderSource(shaderId, source);
        GL20.glCompileShader(shaderId);

        if (GL20.glGetShaderi(shaderId, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            throw new IllegalStateException("Shader compile failed: " + GL20.glGetShaderInfoLog(shaderId));
        }

        return shaderId;
    }
}

