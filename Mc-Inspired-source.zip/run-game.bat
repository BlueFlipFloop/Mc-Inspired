@echo off
setlocal

cd /d "%~dp0"
call "%~dp0gradle-local.bat" run

if errorlevel 1 (
    echo.
    echo Launch failed. Press any key to close this window.
    pause >nul
)
