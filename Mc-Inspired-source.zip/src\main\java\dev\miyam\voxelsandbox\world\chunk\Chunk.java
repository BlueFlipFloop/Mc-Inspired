package dev.miyam.voxelsandbox.world.chunk;

import dev.miyam.voxelsandbox.game.blocks.BlockType;

public final class Chunk {
    public static final int SIZE_X = 16;
    public static final int SIZE_Y = 96;
    public static final int SIZE_Z = 16;

    private final ChunkPos position;
    private final byte[] blocks = new byte[SIZE_X * SIZE_Y * SIZE_Z];

    public Chunk(ChunkPos position) {
        this.position = position;
    }

    public ChunkPos position() {
        return position;
    }

    public void setBlock(int x, int y, int z, BlockType type) {
        blocks[index(x, y, z)] = type.id();
    }

    public byte getBlockId(int x, int y, int z) {
        if (x < 0 || y < 0 || z < 0 || x >= SIZE_X || y >= SIZE_Y || z >= SIZE_Z) {
            return BlockType.AIR.id();
        }
        return blocks[index(x, y, z)];
    }

    public BlockType getBlockType(int x, int y, int z) {
        return BlockType.byId(getBlockId(x, y, z));
    }

    public int minWorldX() {
        return position.minBlockX();
    }

    public int minWorldZ() {
        return position.minBlockZ();
    }

    private int index(int x, int y, int z) {
        return x + SIZE_X * (z + SIZE_Z * y);
    }
}

