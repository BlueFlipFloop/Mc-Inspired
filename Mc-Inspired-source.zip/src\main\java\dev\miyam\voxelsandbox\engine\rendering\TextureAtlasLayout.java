package dev.miyam.voxelsandbox.engine.rendering;

public final class TextureAtlasLayout {
    private final int textureWidth;
    private final int textureHeight;
    private final int tileWidth;
    private final int tileHeight;
    private final int columns;
    private final int rows;

    public TextureAtlasLayout(int textureWidth, int textureHeight, int tileWidth, int tileHeight) {
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.tileWidth = tileWidth;
        this.tileHeight = tileHeight;
        this.columns = textureWidth / tileWidth;
        this.rows = textureHeight / tileHeight;
    }

    public AtlasRegion regionFor(int tileIndex) {
        int tileX = tileIndex % columns;
        int tileY = tileIndex / columns;

        float epsilonU = 0.5f / textureWidth;
        float epsilonV = 0.5f / textureHeight;
        float minU = tileX * tileWidth / (float) textureWidth + epsilonU;
        float minV = tileY * tileHeight / (float) textureHeight + epsilonV;
        float maxU = (tileX + 1) * tileWidth / (float) textureWidth - epsilonU;
        float maxV = (tileY + 1) * tileHeight / (float) textureHeight - epsilonV;
        return new AtlasRegion(minU, minV, maxU, maxV);
    }

    public int columns() {
        return columns;
    }

    public int rows() {
        return rows;
    }
}

