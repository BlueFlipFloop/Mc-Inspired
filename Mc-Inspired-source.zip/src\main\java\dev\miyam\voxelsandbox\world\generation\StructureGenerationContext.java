package dev.miyam.voxelsandbox.world.generation;

import dev.miyam.voxelsandbox.game.biomes.BiomeType;
import dev.miyam.voxelsandbox.game.blocks.BlockType;

public record StructureGenerationContext(
        int seed,
        TerrainGenerator terrainGenerator
) {
    public BiomeType biomeAt(int worldX, int worldZ) {
        return terrainGenerator.sampleBiome(worldX, worldZ);
    }

    public int surfaceHeightAt(int worldX, int worldZ) {
        return terrainGenerator.sampleSurfaceHeight(worldX, worldZ);
    }

    public BlockType blockAt(int worldX, int worldY, int worldZ) {
        return terrainGenerator.sampleBlock(worldX, worldY, worldZ);
    }
}
