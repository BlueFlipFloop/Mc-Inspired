package dev.miyam.voxelsandbox.engine.util;

import java.util.Arrays;

public final class FloatArrayBuilder {
    private float[] values;
    private int size;

    public FloatArrayBuilder(int initialCapacity) {
        values = new float[Math.max(initialCapacity, 16)];
    }

    public void add(float value) {
        ensureCapacity(1);
        values[size++] = value;
    }

    public int size() {
        return size;
    }

    public float[] toArray() {
        return Arrays.copyOf(values, size);
    }

    private void ensureCapacity(int additional) {
        int required = size + additional;
        if (required <= values.length) {
            return;
        }

        int newCapacity = values.length;
        while (newCapacity < required) {
            newCapacity <<= 1;
        }
        values = Arrays.copyOf(values, newCapacity);
    }
}
