# Voxel Sandbox

Java 21 + LWJGL 3 voxel sandbox foundation focused on modern OpenGL, asynchronous chunk generation, greedy meshing, and scalable package boundaries for future gameplay growth.

## Included Foundation

- Gradle 8.14.5 wrapper
- Local Java 21 workspace install under `.tools`
- LWJGL 3.3.6 with GLFW, OpenGL, STB, and OpenAL
- JOML math library
- Core engine loop, windowing, input, camera, shader loading, texture loading
- Async chunk generation
- Greedy meshing
- Texture atlas support
- Frustum culling
- Debug overlay

## Build

Use the local helper so the workspace JDK and Gradle cache are wired automatically:

```powershell
.\gradle-local.bat build
```

## Run

```powershell
.\gradle-local.bat run
```

## Controls

- `WASD`: move
- `Mouse`: look
- `Space`: jump
- `Left Control`: sprint
- `Left Shift`: crouch / sneak
- `F3`: debug overlay
- `F4`: collision box debug
- `F5`: wireframe mode
- `F6`: chunk state bounds debug

## Key Files

- [build.gradle.kts](/C:/Users/miyam/Documents/Codex/2026-05-07/are-you-able-to-download-all/build.gradle.kts)
- [docs/architecture.md](/C:/Users/miyam/Documents/Codex/2026-05-07/are-you-able-to-download-all/docs/architecture.md)
- [src/main/java/dev/miyam/voxelsandbox/game/VoxelSandbox.java](/C:/Users/miyam/Documents/Codex/2026-05-07/are-you-able-to-download-all/src/main/java/dev/miyam/voxelsandbox/game/VoxelSandbox.java)
- [src/main/java/dev/miyam/voxelsandbox/world/terrain/World.java](/C:/Users/miyam/Documents/Codex/2026-05-07/are-you-able-to-download-all/src/main/java/dev/miyam/voxelsandbox/world/terrain/World.java)
- [src/main/java/dev/miyam/voxelsandbox/world/chunk/ChunkMesher.java](/C:/Users/miyam/Documents/Codex/2026-05-07/are-you-able-to-download-all/src/main/java/dev/miyam/voxelsandbox/world/chunk/ChunkMesher.java)
