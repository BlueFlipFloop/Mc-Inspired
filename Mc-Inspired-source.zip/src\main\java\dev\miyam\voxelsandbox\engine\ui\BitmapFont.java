package dev.miyam.voxelsandbox.engine.ui;

import java.nio.ByteBuffer;
import java.util.LinkedHashMap;
import java.util.Map;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL30;

public final class BitmapFont implements AutoCloseable {
    private static final int GLYPH_WIDTH = 5;
    private static final int GLYPH_HEIGHT = 7;
    private static final int CELL_WIDTH = 6;
    private static final int CELL_HEIGHT = 8;
    private static final String CHARACTERS = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:,-/";

    private final int textureId;
    private final Map<Character, Glyph> glyphs;
    private final int textureWidth;
    private final int textureHeight;

    public BitmapFont() {
        glyphs = new LinkedHashMap<>();
        int columns = 8;
        int rows = (int) Math.ceil(CHARACTERS.length() / (double) columns);
        textureWidth = columns * CELL_WIDTH;
        textureHeight = rows * CELL_HEIGHT;

        ByteBuffer pixels = BufferUtils.createByteBuffer(textureWidth * textureHeight);
        Map<Character, String[]> patterns = patterns();

        for (int i = 0; i < CHARACTERS.length(); i++) {
            char character = CHARACTERS.charAt(i);
            int cellX = (i % columns) * CELL_WIDTH;
            int cellY = (i / columns) * CELL_HEIGHT;
            String[] pattern = patterns.getOrDefault(character, patterns.get(' '));
            glyphs.put(character, new Glyph(
                    cellX / (float) textureWidth,
                    cellY / (float) textureHeight,
                    (cellX + GLYPH_WIDTH) / (float) textureWidth,
                    (cellY + GLYPH_HEIGHT) / (float) textureHeight
            ));

            for (int py = 0; py < GLYPH_HEIGHT; py++) {
                for (int px = 0; px < GLYPH_WIDTH; px++) {
                    int index = (cellX + px) + textureWidth * (cellY + py);
                    pixels.put(index, (byte) (pattern[py].charAt(px) == '#' ? 0xFF : 0x00));
                }
            }
        }

        textureId = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
        GL11.glPixelStorei(GL11.GL_UNPACK_ALIGNMENT, 1);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        GL11.glTexImage2D(
                GL11.GL_TEXTURE_2D,
                0,
                GL30.GL_R8,
                textureWidth,
                textureHeight,
                0,
                GL11.GL_RED,
                GL11.GL_UNSIGNED_BYTE,
                pixels
        );
    }

    public int textureId() {
        return textureId;
    }

    public Glyph glyph(char character) {
        return glyphs.getOrDefault(Character.toUpperCase(character), glyphs.get(' '));
    }

    public int glyphWidth() {
        return GLYPH_WIDTH;
    }

    public int glyphHeight() {
        return GLYPH_HEIGHT;
    }

    public int advance() {
        return CELL_WIDTH;
    }

    @Override
    public void close() {
        GL11.glDeleteTextures(textureId);
    }

    private Map<Character, String[]> patterns() {
        Map<Character, String[]> patterns = new LinkedHashMap<>();
        patterns.put(' ', rows(".....", ".....", ".....", ".....", ".....", ".....", "....."));
        patterns.put('A', rows(".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"));
        patterns.put('B', rows("####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."));
        patterns.put('C', rows(".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."));
        patterns.put('D', rows("####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."));
        patterns.put('E', rows("#####", "#....", "#....", "####.", "#....", "#....", "#####"));
        patterns.put('F', rows("#####", "#....", "#....", "####.", "#....", "#....", "#...."));
        patterns.put('G', rows(".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".###."));
        patterns.put('H', rows("#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"));
        patterns.put('I', rows("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "#####"));
        patterns.put('J', rows("..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."));
        patterns.put('K', rows("#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"));
        patterns.put('L', rows("#....", "#....", "#....", "#....", "#....", "#....", "#####"));
        patterns.put('M', rows("#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"));
        patterns.put('N', rows("#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", "#...#"));
        patterns.put('O', rows(".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."));
        patterns.put('P', rows("####.", "#...#", "#...#", "####.", "#....", "#....", "#...."));
        patterns.put('Q', rows(".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"));
        patterns.put('R', rows("####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"));
        patterns.put('S', rows(".####", "#....", "#....", ".###.", "....#", "....#", "####."));
        patterns.put('T', rows("#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."));
        patterns.put('U', rows("#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."));
        patterns.put('V', rows("#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."));
        patterns.put('W', rows("#...#", "#...#", "#...#", "#.#.#", "#.#.#", "##.##", "#...#"));
        patterns.put('X', rows("#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"));
        patterns.put('Y', rows("#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."));
        patterns.put('Z', rows("#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"));
        patterns.put('0', rows(".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."));
        patterns.put('1', rows("..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."));
        patterns.put('2', rows(".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"));
        patterns.put('3', rows("#####", "....#", "...#.", "..##.", "....#", "#...#", ".###."));
        patterns.put('4', rows("...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."));
        patterns.put('5', rows("#####", "#....", "#....", "####.", "....#", "....#", "####."));
        patterns.put('6', rows(".###.", "#....", "#....", "####.", "#...#", "#...#", ".###."));
        patterns.put('7', rows("#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."));
        patterns.put('8', rows(".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."));
        patterns.put('9', rows(".###.", "#...#", "#...#", ".####", "....#", "....#", ".###."));
        patterns.put('.', rows(".....", ".....", ".....", ".....", ".....", "..##.", "..##."));
        patterns.put(':', rows(".....", "..##.", "..##.", ".....", "..##.", "..##.", "....."));
        patterns.put(',', rows(".....", ".....", ".....", ".....", "..##.", "..##.", ".##.."));
        patterns.put('-', rows(".....", ".....", ".....", ".###.", ".....", ".....", "....."));
        patterns.put('/', rows("....#", "...#.", "...#.", "..#..", ".#...", ".#...", "#...."));
        return patterns;
    }

    private String[] rows(String... rows) {
        return rows;
    }

    public record Glyph(float minU, float minV, float maxU, float maxV) {
    }
}
