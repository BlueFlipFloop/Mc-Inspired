/**
 * Magic progression systems and spell data live here.
 */
package dev.miyam.voxelsandbox.game.magic;

