package dev.miyam.voxelsandbox.engine;

import java.util.Objects;
import java.util.function.BiConsumer;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

public final class Window implements AutoCloseable {
    private final EngineConfig config;

    private long handle;
    private int width;
    private int height;
    private BiConsumer<Integer, Integer> resizeCallback = (w, h) -> {
    };

    public Window(EngineConfig config) {
        this.config = Objects.requireNonNull(config);
        this.width = config.width();
        this.height = config.height();
    }

    public void create() {
        GLFWErrorCallback.createPrint(System.err).set();
        if (!GLFW.glfwInit()) {
            throw new IllegalStateException("Unable to initialize GLFW");
        }

        GLFW.glfwDefaultWindowHints();
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR, 4);
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR, 1);
        GLFW.glfwWindowHint(GLFW.GLFW_OPENGL_PROFILE, GLFW.GLFW_OPENGL_CORE_PROFILE);
        GLFW.glfwWindowHint(GLFW.GLFW_OPENGL_FORWARD_COMPAT, GLFW.GLFW_TRUE);
        GLFW.glfwWindowHint(GLFW.GLFW_RESIZABLE, config.resizable() ? GLFW.GLFW_TRUE : GLFW.GLFW_FALSE);
        GLFW.glfwWindowHint(GLFW.GLFW_OPENGL_DEBUG_CONTEXT, config.debugContext() ? GLFW.GLFW_TRUE : GLFW.GLFW_FALSE);

        handle = GLFW.glfwCreateWindow(width, height, config.title(), MemoryUtil.NULL, MemoryUtil.NULL);
        if (handle == MemoryUtil.NULL) {
            throw new IllegalStateException("Unable to create GLFW window");
        }

        GLFWVidMode videoMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
        if (videoMode != null) {
            GLFW.glfwSetWindowPos(
                    handle,
                    (videoMode.width() - width) / 2,
                    (videoMode.height() - height) / 2
            );
        }

        GLFW.glfwMakeContextCurrent(handle);
        GLFW.glfwSwapInterval(config.vSync() ? 1 : 0);
        GLFW.glfwShowWindow(handle);

        GLFW.glfwSetFramebufferSizeCallback(handle, (windowHandle, framebufferWidth, framebufferHeight) -> {
            width = Math.max(framebufferWidth, 1);
            height = Math.max(framebufferHeight, 1);
            GL11.glViewport(0, 0, width, height);
            resizeCallback.accept(width, height);
        });
    }

    public void beginFrame() {
        GLFW.glfwPollEvents();
    }

    public void endFrame() {
        GLFW.glfwSwapBuffers(handle);
    }

    public void setResizeCallback(BiConsumer<Integer, Integer> resizeCallback) {
        this.resizeCallback = Objects.requireNonNull(resizeCallback);
    }

    public long getHandle() {
        return handle;
    }

    public boolean shouldClose() {
        return GLFW.glfwWindowShouldClose(handle);
    }

    public void requestClose() {
        GLFW.glfwSetWindowShouldClose(handle, true);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public float aspectRatio() {
        return width / (float) height;
    }

    public void setTitle(String title) {
        GLFW.glfwSetWindowTitle(handle, title);
    }

    @Override
    public void close() {
        if (handle != MemoryUtil.NULL) {
            GLFW.glfwDestroyWindow(handle);
            GLFW.glfwTerminate();
            GLFW.glfwSetErrorCallback(null).free();
            handle = MemoryUtil.NULL;
        }
    }
}

