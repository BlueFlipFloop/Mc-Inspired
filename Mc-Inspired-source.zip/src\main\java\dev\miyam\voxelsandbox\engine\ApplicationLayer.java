package dev.miyam.voxelsandbox.engine;

public interface ApplicationLayer {
    void initialize(EngineContext context);

    void update(double deltaTime);

    void render(double alpha);

    void resize(int width, int height);

    void dispose();
}

