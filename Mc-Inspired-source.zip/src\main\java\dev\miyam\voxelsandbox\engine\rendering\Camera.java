package dev.miyam.voxelsandbox.engine.rendering;

import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class Camera {
    private final Vector3f position = new Vector3f();
    private final Matrix4f projection = new Matrix4f();
    private final Matrix4f view = new Matrix4f();
    private final Frustum frustum = new Frustum();

    private float yaw = -90.0f;
    private float pitch = 0.0f;
    private float fov = 75.0f;
    private float nearPlane = 0.05f;
    private float farPlane = 320.0f;

    public Camera(float aspectRatio) {
        position.set(0.0f, 72.0f, 0.0f);
        updateProjection(aspectRatio);
        updateView();
    }

    public void updateProjection(float aspectRatio) {
        projection.identity().perspective((float) Math.toRadians(fov), aspectRatio, nearPlane, farPlane);
        frustum.update(combinedMatrix());
    }

    public void updateView() {
        Vector3f target = new Vector3f(position).add(forward());
        view.identity().lookAt(position, target, new Vector3f(0.0f, 1.0f, 0.0f));
        frustum.update(combinedMatrix());
    }

    public void rotate(float yawDelta, float pitchDelta) {
        yaw += yawDelta;
        pitch = clamp(pitch + pitchDelta, -89.0f, 89.0f);
        updateView();
    }

    public void setPosition(Vector3f position) {
        this.position.set(position);
        updateView();
    }

    public Vector3f position() {
        return position;
    }

    public Matrix4f projection() {
        return projection;
    }

    public Matrix4f view() {
        return view;
    }

    public Frustum frustum() {
        return frustum;
    }

    public Vector3f forward() {
        float yawRadians = (float) Math.toRadians(yaw);
        float pitchRadians = (float) Math.toRadians(pitch);
        return new Vector3f(
                (float) (Math.cos(yawRadians) * Math.cos(pitchRadians)),
                (float) Math.sin(pitchRadians),
                (float) (Math.sin(yawRadians) * Math.cos(pitchRadians))
        ).normalize();
    }

    public Vector3f right() {
        return forward().cross(0.0f, 1.0f, 0.0f, new Vector3f()).normalize();
    }

    public float pitch() {
        return pitch;
    }

    public float yaw() {
        return yaw;
    }

    public void setFarPlane(float farPlane) {
        this.farPlane = farPlane;
    }

    private Matrix4f combinedMatrix() {
        return new Matrix4f(projection).mul(view);
    }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
