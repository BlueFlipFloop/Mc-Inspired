package dev.miyam.voxelsandbox.game.entities;

import dev.miyam.voxelsandbox.engine.physics.Aabb;
import dev.miyam.voxelsandbox.engine.rendering.Camera;
import org.joml.Vector3f;

public final class Player {
    public static final float WIDTH = 0.6f;
    public static final float HALF_WIDTH = WIDTH * 0.5f;
    public static final float STANDING_HEIGHT = 1.8f;
    public static final float CROUCHING_HEIGHT = 1.5f;
    public static final float STANDING_EYE_HEIGHT = 1.62f;
    public static final float CROUCHING_EYE_HEIGHT = 1.35f;

    private final Vector3f position = new Vector3f();
    private final Vector3f previousPosition = new Vector3f();
    private final Vector3f velocity = new Vector3f();
    private final Vector3f interpolatedCameraPosition = new Vector3f();
    private final Aabb collisionBounds = new Aabb();

    private boolean grounded;
    private boolean crouching;
    private boolean sprinting;
    private float currentHeight = STANDING_HEIGHT;
    private float previousHeight = STANDING_HEIGHT;
    private float currentEyeHeight = STANDING_EYE_HEIGHT;
    private float previousEyeHeight = STANDING_EYE_HEIGHT;
    private float fallDistance;
    private float lastLandingSpeed;

    public void setSpawn(float x, float y, float z) {
        position.set(x, y, z);
        previousPosition.set(position);
        velocity.zero();
        refreshBounds();
    }

    public void beginPhysicsStep() {
        previousPosition.set(position);
        previousHeight = currentHeight;
        previousEyeHeight = currentEyeHeight;
    }

    public void syncCamera(Camera camera, double alpha) {
        float blend = (float) alpha;
        float x = previousPosition.x + (position.x - previousPosition.x) * blend;
        float y = previousPosition.y + (position.y - previousPosition.y) * blend;
        float z = previousPosition.z + (position.z - previousPosition.z) * blend;
        float eyeHeight = previousEyeHeight + (currentEyeHeight - previousEyeHeight) * blend;
        interpolatedCameraPosition.set(x, y + eyeHeight, z);
        camera.setPosition(interpolatedCameraPosition);
    }

    public Vector3f position() {
        return position;
    }

    public Vector3f velocity() {
        return velocity;
    }

    public Aabb collisionBounds() {
        return collisionBounds;
    }

    public boolean grounded() {
        return grounded;
    }

    public void setGrounded(boolean grounded) {
        this.grounded = grounded;
    }

    public boolean crouching() {
        return crouching;
    }

    public void setCrouching(boolean crouching) {
        this.crouching = crouching;
    }

    public boolean sprinting() {
        return sprinting;
    }

    public void setSprinting(boolean sprinting) {
        this.sprinting = sprinting;
    }

    public float currentHeight() {
        return currentHeight;
    }

    public float targetHeight() {
        return crouching ? CROUCHING_HEIGHT : STANDING_HEIGHT;
    }

    public float targetEyeHeight() {
        return crouching ? CROUCHING_EYE_HEIGHT : STANDING_EYE_HEIGHT;
    }

    public void applyStance(float heightLerpFactor) {
        currentHeight += (targetHeight() - currentHeight) * heightLerpFactor;
        currentEyeHeight += (targetEyeHeight() - currentEyeHeight) * heightLerpFactor;
        refreshBounds();
    }

    public void snapToStandingHeight() {
        currentHeight = STANDING_HEIGHT;
        previousHeight = currentHeight;
        currentEyeHeight = STANDING_EYE_HEIGHT;
        previousEyeHeight = currentEyeHeight;
        refreshBounds();
    }

    public void move(float dx, float dy, float dz) {
        position.add(dx, dy, dz);
        refreshBounds();
    }

    public void refreshBounds() {
        collisionBounds.setFromFootPosition(position.x, position.y, position.z, HALF_WIDTH, currentHeight);
    }

    public float fallDistance() {
        return fallDistance;
    }

    public void resetFallDistance() {
        fallDistance = 0.0f;
    }

    public void addFallDistance(float amount) {
        fallDistance += amount;
    }

    public float lastLandingSpeed() {
        return lastLandingSpeed;
    }

    public void setLastLandingSpeed(float lastLandingSpeed) {
        this.lastLandingSpeed = lastLandingSpeed;
    }
}
