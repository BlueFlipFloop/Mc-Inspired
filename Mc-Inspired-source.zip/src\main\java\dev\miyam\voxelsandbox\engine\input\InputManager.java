package dev.miyam.voxelsandbox.engine.input;

import dev.miyam.voxelsandbox.engine.Window;
import org.lwjgl.glfw.GLFW;

public final class InputManager {
    private final Window window;
    private final boolean[] down = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private final boolean[] pressed = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private final boolean[] released = new boolean[GLFW.GLFW_KEY_LAST + 1];
    private final boolean[] mouseDown = new boolean[GLFW.GLFW_MOUSE_BUTTON_LAST + 1];
    private final boolean[] mousePressed = new boolean[GLFW.GLFW_MOUSE_BUTTON_LAST + 1];
    private final boolean[] mouseReleased = new boolean[GLFW.GLFW_MOUSE_BUTTON_LAST + 1];

    private double mouseX;
    private double mouseY;
    private double deltaX;
    private double deltaY;
    private double scrollX;
    private double scrollY;
    private boolean firstMouseSample = true;

    public InputManager(Window window) {
        this.window = window;

        GLFW.glfwSetKeyCallback(window.getHandle(), (handle, key, scancode, action, mods) -> {
            if (key < 0 || key >= down.length) {
                return;
            }
            if (action == GLFW.GLFW_PRESS) {
                down[key] = true;
                pressed[key] = true;
            } else if (action == GLFW.GLFW_RELEASE) {
                down[key] = false;
                released[key] = true;
            }
        });

        GLFW.glfwSetMouseButtonCallback(window.getHandle(), (handle, button, action, mods) -> {
            if (button < 0 || button >= mouseDown.length) {
                return;
            }
            if (action == GLFW.GLFW_PRESS) {
                mouseDown[button] = true;
                mousePressed[button] = true;
            } else if (action == GLFW.GLFW_RELEASE) {
                mouseDown[button] = false;
                mouseReleased[button] = true;
            }
        });

        GLFW.glfwSetCursorPosCallback(window.getHandle(), (handle, xpos, ypos) -> {
            if (firstMouseSample) {
                mouseX = xpos;
                mouseY = ypos;
                firstMouseSample = false;
            }

            deltaX += xpos - mouseX;
            deltaY += ypos - mouseY;
            mouseX = xpos;
            mouseY = ypos;
        });

        GLFW.glfwSetScrollCallback(window.getHandle(), (handle, xoffset, yoffset) -> {
            scrollX += xoffset;
            scrollY += yoffset;
        });
    }

    public void beginFrame() {
        clearFrameFlags(pressed);
        clearFrameFlags(released);
        clearFrameFlags(mousePressed);
        clearFrameFlags(mouseReleased);
        deltaX = 0.0;
        deltaY = 0.0;
        scrollX = 0.0;
        scrollY = 0.0;
    }

    public void endFrame() {
    }

    public boolean isKeyDown(int key) {
        return key >= 0 && key < down.length && down[key];
    }

    public boolean wasKeyPressed(int key) {
        return key >= 0 && key < pressed.length && pressed[key];
    }

    public boolean wasKeyReleased(int key) {
        return key >= 0 && key < released.length && released[key];
    }

    public boolean isMouseDown(int button) {
        return button >= 0 && button < mouseDown.length && mouseDown[button];
    }

    public double getDeltaX() {
        return deltaX;
    }

    public double getDeltaY() {
        return deltaY;
    }

    public double getScrollY() {
        return scrollY;
    }

    public void setCursorCaptured(boolean captured) {
        GLFW.glfwSetInputMode(
                window.getHandle(),
                GLFW.GLFW_CURSOR,
                captured ? GLFW.GLFW_CURSOR_DISABLED : GLFW.GLFW_CURSOR_NORMAL
        );

        if (captured && GLFW.glfwRawMouseMotionSupported()) {
            GLFW.glfwSetInputMode(window.getHandle(), GLFW.GLFW_RAW_MOUSE_MOTION, GLFW.GLFW_TRUE);
        }
    }

    private void clearFrameFlags(boolean[] flags) {
        for (int i = 0; i < flags.length; i++) {
            flags[i] = false;
        }
    }
}

