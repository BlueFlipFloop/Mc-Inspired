package dev.miyam.voxelsandbox.engine.input;

import dev.miyam.voxelsandbox.engine.physics.Aabb;
import dev.miyam.voxelsandbox.engine.physics.VoxelCollisionResolver;
import dev.miyam.voxelsandbox.engine.physics.VoxelCollisionWorld;
import dev.miyam.voxelsandbox.engine.rendering.Camera;
import dev.miyam.voxelsandbox.game.entities.Player;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;

public final class FirstPersonController {
    private static final float GRAVITY = 32.0f;
    private static final float JUMP_VELOCITY = 8.8f;
    private static final float TERMINAL_VELOCITY = 38.0f;
    private static final float WALK_SPEED = 4.6f;
    private static final float SPRINT_SPEED = 6.2f;
    private static final float CROUCH_SPEED = 2.25f;
    private static final float GROUND_ACCELERATION = 42.0f;
    private static final float AIR_ACCELERATION = 10.0f;
    private static final float GROUND_FRICTION = 18.0f;
    private static final float AIR_DRAG = 1.2f;
    private static final float STEP_HEIGHT = 0.6f;

    private final Camera camera;
    private final Player player;
    private final VoxelCollisionResolver collisionResolver;
    private final Aabb scratchBounds = new Aabb();
    private final Aabb stepBounds = new Aabb();
    private final Aabb stanceBounds = new Aabb();
    private final Vector3f wishVector = new Vector3f();
    private final Vector2f horizontalVelocity = new Vector2f();

    private float mouseSensitivity = 0.11f;

    public FirstPersonController(Camera camera, Player player, VoxelCollisionWorld world) {
        this.camera = camera;
        this.player = player;
        this.collisionResolver = new VoxelCollisionResolver(world);
    }

    public void update(InputManager input, double deltaTime) {
        player.beginPhysicsStep();
        updateLook(input);
        updateMovementState(input);
        applyHorizontalIntent(input, (float) deltaTime);
        applyVerticalForces(input, (float) deltaTime);
        resolveMovement((float) deltaTime);
        updateStance();
    }

    public float mouseSensitivity() {
        return mouseSensitivity;
    }

    private void updateLook(InputManager input) {
        float yawDelta = (float) input.getDeltaX() * mouseSensitivity;
        float pitchDelta = (float) input.getDeltaY() * mouseSensitivity;
        camera.rotate(yawDelta, -pitchDelta);
    }

    private void updateMovementState(InputManager input) {
        player.setCrouching(input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT));
        player.setSprinting(input.isKeyDown(GLFW.GLFW_KEY_LEFT_CONTROL) && !player.crouching());
    }

    private void applyHorizontalIntent(InputManager input, float deltaTime) {
        wishVector.zero();
        Vector3f forward = camera.forward();
        Vector3f right = camera.right();

        if (input.isKeyDown(GLFW.GLFW_KEY_W)) {
            wishVector.add(forward.x, 0.0f, forward.z);
        }
        if (input.isKeyDown(GLFW.GLFW_KEY_S)) {
            wishVector.sub(forward.x, 0.0f, forward.z);
        }
        if (input.isKeyDown(GLFW.GLFW_KEY_D)) {
            wishVector.add(right.x, 0.0f, right.z);
        }
        if (input.isKeyDown(GLFW.GLFW_KEY_A)) {
            wishVector.sub(right.x, 0.0f, right.z);
        }

        if (wishVector.lengthSquared() > 0.0f) {
            wishVector.normalize();
        }

        float targetSpeed = player.crouching() ? CROUCH_SPEED : (player.sprinting() ? SPRINT_SPEED : WALK_SPEED);
        float desiredX = wishVector.x * targetSpeed;
        float desiredZ = wishVector.z * targetSpeed;

        horizontalVelocity.set(player.velocity().x, player.velocity().z);
        float acceleration = player.grounded() ? GROUND_ACCELERATION : AIR_ACCELERATION;
        float blend = Math.min(1.0f, acceleration * deltaTime);
        horizontalVelocity.x += (desiredX - horizontalVelocity.x) * blend;
        horizontalVelocity.y += (desiredZ - horizontalVelocity.y) * blend;

        if (wishVector.lengthSquared() == 0.0f) {
            float drag = Math.max(0.0f, 1.0f - (player.grounded() ? GROUND_FRICTION : AIR_DRAG) * deltaTime);
            horizontalVelocity.mul(drag);
        }

        player.velocity().x = horizontalVelocity.x;
        player.velocity().z = horizontalVelocity.y;
    }

    private void applyVerticalForces(InputManager input, float deltaTime) {
        if (player.grounded()) {
            if (player.velocity().y < 0.0f) {
                player.velocity().y = 0.0f;
            }
            if (input.wasKeyPressed(GLFW.GLFW_KEY_SPACE)) {
                player.velocity().y = JUMP_VELOCITY;
                player.setGrounded(false);
                player.resetFallDistance();
            }
        }

        player.velocity().y = Math.max(player.velocity().y - GRAVITY * deltaTime, -TERMINAL_VELOCITY);
    }

    private void resolveMovement(float deltaTime) {
        float deltaX = player.velocity().x * deltaTime;
        float deltaY = player.velocity().y * deltaTime;
        float deltaZ = player.velocity().z * deltaTime;
        float verticalVelocityBeforeMove = player.velocity().y;
        float startY = player.position().y;
        boolean stepped = false;

        scratchBounds.set(player.collisionBounds());

        float resolvedY = collisionResolver.moveY(scratchBounds, deltaY);
        scratchBounds.translate(0.0f, resolvedY, 0.0f);

        float resolvedX = collisionResolver.moveX(scratchBounds, deltaX);
        scratchBounds.translate(resolvedX, 0.0f, 0.0f);

        float resolvedZ = collisionResolver.moveZ(scratchBounds, deltaZ);
        scratchBounds.translate(0.0f, 0.0f, resolvedZ);

        boolean horizontalBlocked = Math.abs(resolvedX - deltaX) > 0.0001f || Math.abs(resolvedZ - deltaZ) > 0.0001f;
        if (horizontalBlocked && player.grounded()) {
            if (tryStep(deltaX, deltaZ)) {
                stepped = true;
            } else {
                applyResolvedMotion(resolvedX, resolvedY, resolvedZ);
            }
        } else {
            applyResolvedMotion(resolvedX, resolvedY, resolvedZ);
        }

        boolean groundedNow = stepped || (deltaY < 0.0f && resolvedY != deltaY);
        if (groundedNow) {
            if (!player.grounded() && verticalVelocityBeforeMove < -12.0f) {
                player.setLastLandingSpeed(-verticalVelocityBeforeMove);
            }
            player.resetFallDistance();
        } else if (player.velocity().y < 0.0f) {
            player.addFallDistance(Math.max(0.0f, startY - player.position().y));
        }

        player.setGrounded(groundedNow);

        if (stepped || resolvedY != deltaY) {
            player.velocity().y = 0.0f;
        }
        if (resolvedX != deltaX) {
            player.velocity().x = 0.0f;
        }
        if (resolvedZ != deltaZ) {
            player.velocity().z = 0.0f;
        }
    }

    private boolean tryStep(float deltaX, float deltaZ) {
        stepBounds.set(player.collisionBounds());
        float stepUp = collisionResolver.moveY(stepBounds, STEP_HEIGHT);
        if (stepUp <= 0.0f) {
            return false;
        }
        stepBounds.translate(0.0f, stepUp, 0.0f);

        float stepX = collisionResolver.moveX(stepBounds, deltaX);
        stepBounds.translate(stepX, 0.0f, 0.0f);
        float stepZ = collisionResolver.moveZ(stepBounds, deltaZ);
        stepBounds.translate(0.0f, 0.0f, stepZ);

        if (Math.abs(stepX) + Math.abs(stepZ) < 0.001f) {
            return false;
        }

        float stepDown = collisionResolver.moveY(stepBounds, -STEP_HEIGHT - 0.001f);
        stepBounds.translate(0.0f, stepDown, 0.0f);

        player.move(stepX, stepUp + stepDown, stepZ);
        player.setGrounded(true);
        if (player.velocity().y < 0.0f) {
            player.velocity().y = 0.0f;
        }
        return true;
    }

    private void applyResolvedMotion(float resolvedX, float resolvedY, float resolvedZ) {
        player.move(resolvedX, resolvedY, resolvedZ);
    }

    private void updateStance() {
        float targetHeight = player.targetHeight();
        if (targetHeight > player.currentHeight()) {
            stanceBounds.setFromFootPosition(
                    player.position().x,
                    player.position().y,
                    player.position().z,
                    Player.HALF_WIDTH,
                    targetHeight
            );
            if (!collisionResolver.canOccupy(stanceBounds)) {
                player.setCrouching(true);
            }
        }
        player.applyStance(0.35f);
    }
}
