package dev.miyam.voxelsandbox.world.chunk;

import dev.miyam.voxelsandbox.engine.rendering.AtlasRegion;
import dev.miyam.voxelsandbox.engine.rendering.TextureAtlasLayout;
import dev.miyam.voxelsandbox.engine.util.FloatArrayBuilder;
import dev.miyam.voxelsandbox.game.blocks.BlockFace;
import dev.miyam.voxelsandbox.game.blocks.BlockType;
import java.util.Arrays;

public final class ChunkMesher {
    public static final int INSTANCE_STRIDE_FLOATS = 18;

    private final TextureAtlasLayout atlasLayout;

    public ChunkMesher(TextureAtlasLayout atlasLayout) {
        this.atlasLayout = atlasLayout;
    }

    public ChunkMeshData buildMesh(Chunk chunk, BlockResolver resolver) {
        FloatArrayBuilder instances = new FloatArrayBuilder(4096);
        FaceDescriptor[] mask = new FaceDescriptor[Math.max(Chunk.SIZE_X, Math.max(Chunk.SIZE_Y, Chunk.SIZE_Z))
                * Math.max(Chunk.SIZE_X, Math.max(Chunk.SIZE_Y, Chunk.SIZE_Z))];

        int[] dims = {Chunk.SIZE_X, Chunk.SIZE_Y, Chunk.SIZE_Z};
        int[] x = new int[3];
        int[] q = new int[3];

        for (int d = 0; d < 3; d++) {
            int u = (d + 1) % 3;
            int v = (d + 2) % 3;
            Arrays.fill(q, 0);
            q[d] = 1;
            Arrays.fill(x, 0);
            x[d] = -1;

            while (x[d] < dims[d]) {
                int n = 0;
                for (x[v] = 0; x[v] < dims[v]; x[v]++) {
                    for (x[u] = 0; x[u] < dims[u]; x[u]++) {
                        BlockType a = x[d] >= 0 ? blockAt(chunk, resolver, x[0], x[1], x[2]) : BlockType.AIR;
                        BlockType b = x[d] < dims[d] - 1
                                ? blockAt(chunk, resolver, x[0] + q[0], x[1] + q[1], x[2] + q[2])
                                : BlockType.AIR;

                        FaceDescriptor descriptor = null;
                        if (a.solid() != b.solid()) {
                            if (a.solid()) {
                                descriptor = new FaceDescriptor(a, BlockFace.fromAxis(d, true));
                            } else if (b.solid()) {
                                descriptor = new FaceDescriptor(b, BlockFace.fromAxis(d, false));
                            }
                        }
                        mask[n++] = descriptor;
                    }
                }

                x[d]++;
                n = 0;

                for (int j = 0; j < dims[v]; j++) {
                    for (int i = 0; i < dims[u]; ) {
                        FaceDescriptor descriptor = mask[n];
                        if (descriptor == null) {
                            i++;
                            n++;
                            continue;
                        }

                        int width;
                        for (width = 1; i + width < dims[u] && descriptor.equals(mask[n + width]); width++) {
                        }

                        int height;
                        outer:
                        for (height = 1; j + height < dims[v]; height++) {
                            for (int k = 0; k < width; k++) {
                                if (!descriptor.equals(mask[n + k + height * dims[u]])) {
                                    break outer;
                                }
                            }
                        }

                        x[u] = i;
                        x[v] = j;

                        int[] du = {0, 0, 0};
                        int[] dv = {0, 0, 0};
                        du[u] = width;
                        dv[v] = height;

                        addQuadInstance(instances, chunk, descriptor, x, du, dv);

                        for (int l = 0; l < height; l++) {
                            for (int k = 0; k < width; k++) {
                                mask[n + k + l * dims[u]] = null;
                            }
                        }

                        i += width;
                        n += width;
                    }
                }
            }
        }

        return new ChunkMeshData(instances.toArray(), instances.size() / INSTANCE_STRIDE_FLOATS);
    }

    private void addQuadInstance(
            FloatArrayBuilder instances,
            Chunk chunk,
            FaceDescriptor descriptor,
            int[] x,
            int[] du,
            int[] dv
    ) {
        int axis = descriptor.face().ordinal() / 2;
        boolean positive = descriptor.face() == BlockFace.EAST || descriptor.face() == BlockFace.UP || descriptor.face() == BlockFace.SOUTH;

        float originX = chunk.minWorldX() + x[0];
        float originY = x[1];
        float originZ = chunk.minWorldZ() + x[2];
        int duX = du[0];
        int duY = du[1];
        int duZ = du[2];
        int dvX = dv[0];
        int dvY = dv[1];
        int dvZ = dv[2];
        int repeatU = du[0] + du[1] + du[2];
        int repeatV = dv[0] + dv[1] + dv[2];

        if (axis == 0 && positive) {
            originX += 1.0f;
        } else if (axis == 1 && positive) {
            originY += 1.0f;
        } else if (axis == 2 && positive) {
            originZ += 1.0f;
        }

        if (!positive) {
            int swapX = duX;
            int swapY = duY;
            int swapZ = duZ;
            duX = dvX;
            duY = dvY;
            duZ = dvZ;
            dvX = swapX;
            dvY = swapY;
            dvZ = swapZ;

            int swapRepeat = repeatU;
            repeatU = repeatV;
            repeatV = swapRepeat;
        }

        AtlasRegion region = atlasLayout.regionFor(descriptor.blockType().textureIndex(descriptor.face()));

        instances.add(originX);
        instances.add(originY);
        instances.add(originZ);
        instances.add(duX);
        instances.add(duY);
        instances.add(duZ);
        instances.add(dvX);
        instances.add(dvY);
        instances.add(dvZ);
        instances.add(repeatU);
        instances.add(repeatV);
        instances.add(region.minU());
        instances.add(region.minV());
        instances.add(region.maxU());
        instances.add(region.maxV());
        instances.add(descriptor.face().normalX());
        instances.add(descriptor.face().normalY());
        instances.add(descriptor.face().normalZ());
    }

    private BlockType blockAt(Chunk chunk, BlockResolver resolver, int localX, int localY, int localZ) {
        if (localX >= 0 && localY >= 0 && localZ >= 0
                && localX < Chunk.SIZE_X && localY < Chunk.SIZE_Y && localZ < Chunk.SIZE_Z) {
            return chunk.getBlockType(localX, localY, localZ);
        }

        int worldX = chunk.minWorldX() + localX;
        int worldZ = chunk.minWorldZ() + localZ;
        return resolver.blockAt(worldX, localY, worldZ);
    }

    private record FaceDescriptor(BlockType blockType, BlockFace face) {
    }
}
