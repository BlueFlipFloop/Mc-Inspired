package dev.miyam.voxelsandbox.world.generation;

import dev.miyam.voxelsandbox.world.chunk.Chunk;
import dev.miyam.voxelsandbox.world.chunk.ChunkPos;

public interface StructureGenerator {
    void generate(Chunk chunk, ChunkPos position, StructureGenerationContext context);
}

