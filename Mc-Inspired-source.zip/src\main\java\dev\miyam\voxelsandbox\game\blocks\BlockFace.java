package dev.miyam.voxelsandbox.game.blocks;

public enum BlockFace {
    WEST(-1, 0, 0),
    EAST(1, 0, 0),
    DOWN(0, -1, 0),
    UP(0, 1, 0),
    NORTH(0, 0, -1),
    SOUTH(0, 0, 1);

    private final int normalX;
    private final int normalY;
    private final int normalZ;

    BlockFace(int normalX, int normalY, int normalZ) {
        this.normalX = normalX;
        this.normalY = normalY;
        this.normalZ = normalZ;
    }

    public int normalX() {
        return normalX;
    }

    public int normalY() {
        return normalY;
    }

    public int normalZ() {
        return normalZ;
    }

    public static BlockFace fromAxis(int axis, boolean positive) {
        return switch (axis) {
            case 0 -> positive ? EAST : WEST;
            case 1 -> positive ? UP : DOWN;
            case 2 -> positive ? SOUTH : NORTH;
            default -> throw new IllegalArgumentException("Invalid axis: " + axis);
        };
    }
}

