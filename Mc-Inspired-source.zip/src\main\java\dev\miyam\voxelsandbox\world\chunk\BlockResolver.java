package dev.miyam.voxelsandbox.world.chunk;

import dev.miyam.voxelsandbox.game.blocks.BlockType;

@FunctionalInterface
public interface BlockResolver {
    BlockType blockAt(int worldX, int worldY, int worldZ);
}

