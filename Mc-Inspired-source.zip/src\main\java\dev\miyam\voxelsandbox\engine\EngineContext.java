package dev.miyam.voxelsandbox.engine;

import dev.miyam.voxelsandbox.engine.audio.AudioEngine;
import dev.miyam.voxelsandbox.engine.input.InputManager;

public record EngineContext(
        Window window,
        InputManager input,
        AudioEngine audio
) {
}

