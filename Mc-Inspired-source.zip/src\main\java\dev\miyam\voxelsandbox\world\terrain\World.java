package dev.miyam.voxelsandbox.world.terrain;

import dev.miyam.voxelsandbox.engine.physics.VoxelCollisionWorld;
import dev.miyam.voxelsandbox.engine.rendering.GpuChunkMesh;
import dev.miyam.voxelsandbox.game.blocks.BlockType;
import dev.miyam.voxelsandbox.world.chunk.BlockResolver;
import dev.miyam.voxelsandbox.world.chunk.Chunk;
import dev.miyam.voxelsandbox.world.chunk.ChunkMeshData;
import dev.miyam.voxelsandbox.world.chunk.ChunkMesher;
import dev.miyam.voxelsandbox.world.chunk.ChunkPos;
import dev.miyam.voxelsandbox.world.generation.TerrainGenerator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import org.joml.Vector3fc;

public final class World implements AutoCloseable, VoxelCollisionWorld {
    private static final int MAX_GPU_UPLOADS_PER_FRAME = 3;
    private static final int STREAM_MARGIN = 2;
    private static final int COLLISION_GUARD_RADIUS = 2;

    private final TerrainGenerator terrainGenerator;
    private final ChunkMesher chunkMesher;
    private final ExecutorService generationExecutor;
    private final ExecutorService meshExecutor;
    private final PriorityBlockingQueue<GenerationTask> generationQueue = new PriorityBlockingQueue<>();
    private final PriorityBlockingQueue<MeshTask> meshQueue = new PriorityBlockingQueue<>();
    private final ConcurrentLinkedQueue<MeshUpload> completedMeshes = new ConcurrentLinkedQueue<>();
    private final ConcurrentHashMap<ChunkPos, ChunkEntry> chunks = new ConcurrentHashMap<>();
    private final AtomicLong taskSequence = new AtomicLong();
    private final AtomicInteger collisionFallbackQueries = new AtomicInteger();
    private final AtomicInteger meshBuildsQueued = new AtomicInteger();

    private final int viewDistance;
    private final int generationRadius;
    private final int unloadDistance;
    private volatile int centerChunkX;
    private volatile int centerChunkZ;
    private volatile int playerChunkX;
    private volatile int playerChunkZ;
    private int visibleChunkCount;
    private int drawnChunkCount;
    private int lastUploadCount;

    public World(TerrainGenerator terrainGenerator, ChunkMesher chunkMesher, int viewDistance) {
        this.terrainGenerator = Objects.requireNonNull(terrainGenerator);
        this.chunkMesher = Objects.requireNonNull(chunkMesher);
        this.viewDistance = viewDistance;
        this.generationRadius = viewDistance + STREAM_MARGIN;
        this.unloadDistance = generationRadius + 2;

        int availableProcessors = Runtime.getRuntime().availableProcessors();
        int generationWorkers = Math.max(2, availableProcessors / 2);
        int meshWorkers = Math.max(1, availableProcessors - generationWorkers);
        generationExecutor = Executors.newFixedThreadPool(generationWorkers);
        meshExecutor = Executors.newFixedThreadPool(meshWorkers);

        for (int i = 0; i < generationWorkers; i++) {
            generationExecutor.submit(this::generationWorker);
        }
        for (int i = 0; i < meshWorkers; i++) {
            meshExecutor.submit(this::meshWorker);
        }
    }

    public void updateStreaming(Vector3fc focusPosition) {
        centerChunkX = Math.floorDiv((int) Math.floor(focusPosition.x()), Chunk.SIZE_X);
        centerChunkZ = Math.floorDiv((int) Math.floor(focusPosition.z()), Chunk.SIZE_Z);
        playerChunkX = centerChunkX;
        playerChunkZ = centerChunkZ;
        collisionFallbackQueries.set(0);

        List<ChunkPos> desired = new ArrayList<>();
        for (int dz = -generationRadius; dz <= generationRadius; dz++) {
            for (int dx = -generationRadius; dx <= generationRadius; dx++) {
                desired.add(new ChunkPos(centerChunkX + dx, centerChunkZ + dz));
            }
        }
        desired.sort(Comparator.comparingInt(pos -> distanceSquared(pos, centerChunkX, centerChunkZ)));

        for (ChunkPos pos : desired) {
            ChunkEntry entry = chunks.computeIfAbsent(pos, ChunkEntry::new);
            queueGenerationIfNeeded(entry);
            queueMeshIfNeeded(entry);
        }

        for (ChunkEntry entry : chunks.values()) {
            queueMeshIfNeeded(entry);
        }

        List<ChunkPos> toUnload = new ArrayList<>();
        for (Map.Entry<ChunkPos, ChunkEntry> mapEntry : chunks.entrySet()) {
            ChunkPos pos = mapEntry.getKey();
            if (Math.abs(pos.x() - centerChunkX) <= unloadDistance && Math.abs(pos.z() - centerChunkZ) <= unloadDistance) {
                continue;
            }
            if (Math.abs(pos.x() - playerChunkX) <= COLLISION_GUARD_RADIUS && Math.abs(pos.z() - playerChunkZ) <= COLLISION_GUARD_RADIUS) {
                continue;
            }
            toUnload.add(pos);
        }

        for (ChunkPos pos : toUnload) {
            ChunkEntry removed = chunks.remove(pos);
            if (removed != null) {
                GpuChunkMesh mesh = removed.detachMeshForUnload();
                if (mesh != null) {
                    mesh.close();
                }
            }
        }
    }

    public void uploadCompletedMeshes() {
        int uploads = 0;
        MeshUpload upload;
        while (uploads < MAX_GPU_UPLOADS_PER_FRAME && (upload = completedMeshes.poll()) != null) {
            ChunkEntry entry = chunks.get(upload.position());
            if (entry == null || !entry.accepts(upload.generationVersion(), upload.meshVersion())) {
                continue;
            }

            GpuChunkMesh mesh = upload.meshData().isEmpty()
                    ? null
                    : new GpuChunkMesh(upload.meshData().instances(), upload.meshData().instanceCount());
            GpuChunkMesh oldMesh = entry.installMesh(mesh, upload.meshVersion());
            if (oldMesh != null) {
                oldMesh.close();
            }
            uploads++;
        }
        lastUploadCount = uploads;
    }

    public void markChunkDirty(ChunkPos position) {
        ChunkEntry entry = chunks.get(position);
        if (entry == null) {
            return;
        }
        entry.markMeshDirty();
        queueMeshIfNeeded(entry);
    }

    public Collection<ChunkHandle> readyChunkHandles() {
        List<ChunkHandle> ready = new ArrayList<>();
        for (ChunkEntry entry : chunks.values()) {
            GpuChunkMesh mesh = entry.mesh();
            Chunk chunk = entry.chunk();
            if (entry.state() == ChunkState.READY && chunk != null && mesh != null) {
                ready.add(new ChunkHandle(chunk, mesh));
            }
        }
        return ready;
    }

    public Collection<ChunkDebugInfo> debugChunksNear(int radius) {
        List<ChunkDebugInfo> debug = new ArrayList<>();
        for (ChunkEntry entry : chunks.values()) {
            ChunkPos pos = entry.position();
            if (Math.abs(pos.x() - playerChunkX) > radius || Math.abs(pos.z() - playerChunkZ) > radius) {
                continue;
            }
            debug.add(new ChunkDebugInfo(pos, entry.state(), entry.hasChunk(), entry.mesh() != null, entry.meshDirty()));
        }
        debug.sort(Comparator.comparingInt((ChunkDebugInfo info) -> info.position().z())
                .thenComparingInt(info -> info.position().x()));
        return debug;
    }

    public EnumMap<ChunkState, Integer> chunkStateCounts() {
        EnumMap<ChunkState, Integer> counts = new EnumMap<>(ChunkState.class);
        for (ChunkState state : ChunkState.values()) {
            counts.put(state, 0);
        }
        for (ChunkEntry entry : chunks.values()) {
            counts.compute(entry.state(), (state, count) -> count == null ? 1 : count + 1);
        }
        return counts;
    }

    public int loadedChunkCount() {
        return chunks.size();
    }

    public int pendingChunkCount() {
        return generationQueue.size() + meshQueue.size();
    }

    public int visibleChunkCount() {
        return visibleChunkCount;
    }

    public void setVisibleChunkCount(int visibleChunkCount) {
        this.visibleChunkCount = visibleChunkCount;
    }

    public int drawnChunkCount() {
        return drawnChunkCount;
    }

    public void setDrawnChunkCount(int drawnChunkCount) {
        this.drawnChunkCount = drawnChunkCount;
    }

    public int lastUploadCount() {
        return lastUploadCount;
    }

    public int collisionFallbackQueries() {
        return collisionFallbackQueries.get();
    }

    public int meshBuildsQueued() {
        return meshBuildsQueued.get();
    }

    public ChunkPos playerChunkPosition() {
        return new ChunkPos(playerChunkX, playerChunkZ);
    }

    @Override
    public BlockType blockAt(int worldX, int worldY, int worldZ) {
        if (worldY < 0 || worldY >= Chunk.SIZE_Y) {
            return BlockType.AIR;
        }

        ChunkPos position = chunkPosFor(worldX, worldZ);
        ChunkEntry entry = chunks.get(position);
        if (entry != null) {
            Chunk chunk = entry.chunk();
            if (chunk != null) {
                return chunk.getBlockType(Math.floorMod(worldX, Chunk.SIZE_X), worldY, Math.floorMod(worldZ, Chunk.SIZE_Z));
            }
        }

        collisionFallbackQueries.incrementAndGet();
        return terrainGenerator.sampleBlock(worldX, worldY, worldZ);
    }

    @Override
    public int surfaceHeightAt(int worldX, int worldZ) {
        ChunkPos position = chunkPosFor(worldX, worldZ);
        ChunkEntry entry = chunks.get(position);
        if (entry != null) {
            Chunk chunk = entry.chunk();
            if (chunk != null) {
                int localX = Math.floorMod(worldX, Chunk.SIZE_X);
                int localZ = Math.floorMod(worldZ, Chunk.SIZE_Z);
                for (int y = Chunk.SIZE_Y - 1; y >= 0; y--) {
                    if (chunk.getBlockType(localX, y, localZ).collidable()) {
                        return y;
                    }
                }
            }
        }
        return terrainGenerator.sampleSurfaceHeight(worldX, worldZ);
    }

    @Override
    public void close() {
        generationExecutor.shutdownNow();
        meshExecutor.shutdownNow();
        for (ChunkEntry entry : chunks.values()) {
            GpuChunkMesh mesh = entry.detachMeshForUnload();
            if (mesh != null) {
                mesh.close();
            }
        }
        chunks.clear();
    }

    private void queueGenerationIfNeeded(ChunkEntry entry) {
        GenerationTask task = entry.prepareGenerationTask(taskSequence.incrementAndGet(), distanceSquared(entry.position(), centerChunkX, centerChunkZ));
        if (task != null) {
            generationQueue.offer(task);
        }
    }

    private void queueMeshIfNeeded(ChunkEntry entry) {
        MeshTask task = entry.prepareMeshTask(taskSequence.incrementAndGet(), distanceSquared(entry.position(), centerChunkX, centerChunkZ));
        if (task != null) {
            meshBuildsQueued.incrementAndGet();
            meshQueue.offer(task);
        }
    }

    private void generationWorker() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                GenerationTask task = generationQueue.take();
                ChunkEntry entry = chunks.get(task.position());
                if (entry == null || !entry.matchesGenerationTask(task.generationVersion())) {
                    continue;
                }

                Chunk chunk = terrainGenerator.generate(task.position());
                entry.completeGeneration(task.generationVersion(), chunk);
                queueMeshIfNeeded(entry);
                for (ChunkPos neighbor : cardinalNeighbors(task.position())) {
                    ChunkEntry neighborEntry = chunks.get(neighbor);
                    if (neighborEntry != null) {
                        neighborEntry.markMeshDirty();
                        queueMeshIfNeeded(neighborEntry);
                    }
                }
            } catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void meshWorker() {
        while (!Thread.currentThread().isInterrupted()) {
            try {
                MeshTask task = meshQueue.take();
                ChunkEntry entry = chunks.get(task.position());
                if (entry == null) {
                    continue;
                }

                Chunk chunk = entry.chunk();
                if (chunk == null || !entry.matchesMeshTask(task.generationVersion(), task.meshVersion())) {
                    continue;
                }

                BlockResolver resolver = this::blockAtForMeshing;
                ChunkMeshData meshData = chunkMesher.buildMesh(chunk, resolver);
                completedMeshes.add(new MeshUpload(task.position(), task.generationVersion(), task.meshVersion(), meshData));
            } catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private BlockType blockAtForMeshing(int worldX, int worldY, int worldZ) {
        if (worldY < 0 || worldY >= Chunk.SIZE_Y) {
            return BlockType.AIR;
        }

        ChunkPos pos = chunkPosFor(worldX, worldZ);
        ChunkEntry entry = chunks.get(pos);
        if (entry != null) {
            Chunk chunk = entry.chunk();
            if (chunk != null) {
                return chunk.getBlockType(Math.floorMod(worldX, Chunk.SIZE_X), worldY, Math.floorMod(worldZ, Chunk.SIZE_Z));
            }
        }
        return terrainGenerator.sampleBlock(worldX, worldY, worldZ);
    }

    private List<ChunkPos> cardinalNeighbors(ChunkPos position) {
        return List.of(
                new ChunkPos(position.x() - 1, position.z()),
                new ChunkPos(position.x() + 1, position.z()),
                new ChunkPos(position.x(), position.z() - 1),
                new ChunkPos(position.x(), position.z() + 1)
        );
    }

    private ChunkPos chunkPosFor(int worldX, int worldZ) {
        return new ChunkPos(Math.floorDiv(worldX, Chunk.SIZE_X), Math.floorDiv(worldZ, Chunk.SIZE_Z));
    }

    private int distanceSquared(ChunkPos pos, int chunkX, int chunkZ) {
        int dx = pos.x() - chunkX;
        int dz = pos.z() - chunkZ;
        return dx * dx + dz * dz;
    }

    public record ChunkHandle(Chunk chunk, GpuChunkMesh mesh) {
    }

    public record ChunkDebugInfo(
            ChunkPos position,
            ChunkState state,
            boolean hasChunkData,
            boolean hasMesh,
            boolean meshDirty
    ) {
    }

    public enum ChunkState {
        UNLOADED,
        GENERATING,
        GENERATED,
        MESHING,
        READY
    }

    private record GenerationTask(ChunkPos position, long generationVersion, int priority, long sequence)
            implements Comparable<GenerationTask> {
        @Override
        public int compareTo(GenerationTask other) {
            int priorityCompare = Integer.compare(priority, other.priority);
            if (priorityCompare != 0) {
                return priorityCompare;
            }
            return Long.compare(sequence, other.sequence);
        }
    }

    private record MeshTask(ChunkPos position, long generationVersion, long meshVersion, int priority, long sequence)
            implements Comparable<MeshTask> {
        @Override
        public int compareTo(MeshTask other) {
            int priorityCompare = Integer.compare(priority, other.priority);
            if (priorityCompare != 0) {
                return priorityCompare;
            }
            return Long.compare(sequence, other.sequence);
        }
    }

    private record MeshUpload(ChunkPos position, long generationVersion, long meshVersion, ChunkMeshData meshData) {
    }

    private static final class ChunkEntry {
        private final ChunkPos position;
        private volatile ChunkState state = ChunkState.UNLOADED;
        private volatile Chunk chunk;
        private volatile GpuChunkMesh mesh;
        private long generationVersion;
        private long meshVersion;
        private boolean generationQueued;
        private boolean meshQueued;
        private boolean meshDirty = true;

        private ChunkEntry(ChunkPos position) {
            this.position = position;
        }

        public ChunkPos position() {
            return position;
        }

        public ChunkState state() {
            return state;
        }

        public Chunk chunk() {
            return chunk;
        }

        public GpuChunkMesh mesh() {
            return mesh;
        }

        public boolean hasChunk() {
            return chunk != null;
        }

        public boolean meshDirty() {
            return meshDirty;
        }

        public synchronized GenerationTask prepareGenerationTask(long sequence, int priority) {
            if (state != ChunkState.UNLOADED || generationQueued) {
                return null;
            }
            generationQueued = true;
            state = ChunkState.GENERATING;
            generationVersion++;
            return new GenerationTask(position, generationVersion, priority, sequence);
        }

        public synchronized boolean matchesGenerationTask(long expectedGenerationVersion) {
            return generationQueued && generationVersion == expectedGenerationVersion && state == ChunkState.GENERATING;
        }

        public synchronized void completeGeneration(long expectedGenerationVersion, Chunk generatedChunk) {
            if (generationVersion != expectedGenerationVersion) {
                return;
            }
            generationQueued = false;
            chunk = generatedChunk;
            meshDirty = true;
            if (mesh == null) {
                state = ChunkState.GENERATED;
            } else {
                state = ChunkState.READY;
            }
        }

        public synchronized MeshTask prepareMeshTask(long sequence, int priority) {
            if (chunk == null || meshQueued || !meshDirty) {
                return null;
            }
            meshQueued = true;
            meshVersion++;
            if (mesh == null) {
                state = ChunkState.MESHING;
            }
            return new MeshTask(position, generationVersion, meshVersion, priority, sequence);
        }

        public synchronized boolean matchesMeshTask(long expectedGenerationVersion, long expectedMeshVersion) {
            return chunk != null
                    && meshQueued
                    && generationVersion == expectedGenerationVersion
                    && meshVersion == expectedMeshVersion
                    && meshDirty;
        }

        public synchronized boolean accepts(long expectedGenerationVersion, long expectedMeshVersion) {
            return chunk != null
                    && generationVersion == expectedGenerationVersion
                    && meshVersion == expectedMeshVersion;
        }

        public synchronized GpuChunkMesh installMesh(GpuChunkMesh newMesh, long expectedMeshVersion) {
            if (meshVersion != expectedMeshVersion) {
                return newMesh;
            }
            meshQueued = false;
            meshDirty = false;
            GpuChunkMesh previous = mesh;
            mesh = newMesh;
            state = ChunkState.READY;
            return previous;
        }

        public synchronized void markMeshDirty() {
            if (chunk == null) {
                return;
            }
            meshDirty = true;
            if (mesh == null && state != ChunkState.GENERATING) {
                state = ChunkState.GENERATED;
            }
        }

        public synchronized GpuChunkMesh detachMeshForUnload() {
            GpuChunkMesh previous = mesh;
            mesh = null;
            chunk = null;
            meshDirty = true;
            generationQueued = false;
            meshQueued = false;
            state = ChunkState.UNLOADED;
            return previous;
        }
    }
}
