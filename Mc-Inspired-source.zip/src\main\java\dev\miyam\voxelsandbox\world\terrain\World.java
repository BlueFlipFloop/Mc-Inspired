package dev.miyam.voxelsandbox.world.terrain;

import dev.miyam.voxelsandbox.engine.physics.VoxelCollisionWorld;
import dev.miyam.voxelsandbox.engine.rendering.GpuChunkMesh;
import dev.miyam.voxelsandbox.game.blocks.BlockType;
import dev.miyam.voxelsandbox.world.chunk.BlockResolver;
import dev.miyam.voxelsandbox.world.chunk.Chunk;
import dev.miyam.voxelsandbox.world.chunk.ChunkMeshData;
import dev.miyam.voxelsandbox.world.chunk.ChunkMesher;
import dev.miyam.voxelsandbox.world.chunk.ChunkPos;
import dev.miyam.voxelsandbox.world.generation.TerrainGenerator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;
import org.joml.Vector3fc;

public final class World implements AutoCloseable, VoxelCollisionWorld {
    private static final int MAX_GPU_UPLOADS_PER_FRAME = 3;

    private final TerrainGenerator terrainGenerator;
    private final ChunkMesher chunkMesher;
    private final ExecutorService executor;
    private final PriorityBlockingQueue<ChunkRebuildTask> rebuildQueue = new PriorityBlockingQueue<>();
    private final ConcurrentLinkedQueue<CompletedChunk> completedChunks = new ConcurrentLinkedQueue<>();
    private final Map<ChunkPos, ChunkHandle> chunkHandles = new ConcurrentHashMap<>();
    private final Set<ChunkPos> queuedChunks = ConcurrentHashMap.newKeySet();
    private final Set<ChunkPos> buildingChunks = ConcurrentHashMap.newKeySet();
    private final Map<ChunkPos, Long> chunkVersions = new ConcurrentHashMap<>();
    private final AtomicLong buildSequence = new AtomicLong();

    private final int viewDistance;
    private final int unloadDistance;
    private volatile int centerChunkX;
    private volatile int centerChunkZ;
    private int visibleChunkCount;
    private int drawnChunkCount;
    private int lastUploadCount;

    public World(TerrainGenerator terrainGenerator, ChunkMesher chunkMesher, int viewDistance) {
        this.terrainGenerator = Objects.requireNonNull(terrainGenerator);
        this.chunkMesher = Objects.requireNonNull(chunkMesher);
        this.viewDistance = viewDistance;
        this.unloadDistance = viewDistance + 2;
        this.executor = Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors() - 1));

        int workerCount = Math.max(2, Runtime.getRuntime().availableProcessors() - 1);
        for (int i = 0; i < workerCount; i++) {
            executor.submit(this::rebuildWorker);
        }
    }

    public void updateStreaming(Vector3fc focusPosition) {
        centerChunkX = Math.floorDiv((int) Math.floor(focusPosition.x()), Chunk.SIZE_X);
        centerChunkZ = Math.floorDiv((int) Math.floor(focusPosition.z()), Chunk.SIZE_Z);

        List<ChunkPos> needed = new ArrayList<>();
        for (int dz = -viewDistance; dz <= viewDistance; dz++) {
            for (int dx = -viewDistance; dx <= viewDistance; dx++) {
                ChunkPos pos = new ChunkPos(centerChunkX + dx, centerChunkZ + dz);
                if (chunkHandles.containsKey(pos) || queuedChunks.contains(pos) || buildingChunks.contains(pos)) {
                    continue;
                }
                needed.add(pos);
            }
        }

        needed.sort(Comparator.comparingInt(pos -> distanceSquared(pos, centerChunkX, centerChunkZ)));
        for (ChunkPos pos : needed) {
            enqueueRebuild(pos, false);
        }

        List<ChunkPos> toUnload = new ArrayList<>();
        for (ChunkPos pos : chunkHandles.keySet()) {
            if (Math.abs(pos.x() - centerChunkX) > unloadDistance || Math.abs(pos.z() - centerChunkZ) > unloadDistance) {
                toUnload.add(pos);
            }
        }

        for (ChunkPos pos : toUnload) {
            chunkVersions.remove(pos);
            ChunkHandle removed = chunkHandles.remove(pos);
            if (removed != null && removed.mesh() != null) {
                removed.mesh().close();
            }
        }
    }

    public void uploadCompletedMeshes() {
        int uploads = 0;
        CompletedChunk completed;
        while (uploads < MAX_GPU_UPLOADS_PER_FRAME && (completed = completedChunks.poll()) != null) {
            queuedChunks.remove(completed.position());
            if (!shouldAccept(completed.position(), completed.version())) {
                continue;
            }

            GpuChunkMesh mesh = completed.meshData().isEmpty()
                    ? null
                    : new GpuChunkMesh(completed.meshData().instances(), completed.meshData().instanceCount());
            ChunkHandle previous = chunkHandles.put(completed.position(), new ChunkHandle(completed.chunk(), mesh));
            if (previous != null && previous.mesh() != null) {
                previous.mesh().close();
            }
            uploads++;
        }
        lastUploadCount = uploads;
    }

    public void markChunkDirty(ChunkPos position) {
        enqueueRebuild(position, true);
    }

    public Collection<ChunkHandle> chunkHandles() {
        return chunkHandles.values();
    }

    public int loadedChunkCount() {
        return chunkHandles.size();
    }

    public int pendingChunkCount() {
        return rebuildQueue.size() + buildingChunks.size();
    }

    public int visibleChunkCount() {
        return visibleChunkCount;
    }

    public void setVisibleChunkCount(int visibleChunkCount) {
        this.visibleChunkCount = visibleChunkCount;
    }

    public int drawnChunkCount() {
        return drawnChunkCount;
    }

    public void setDrawnChunkCount(int drawnChunkCount) {
        this.drawnChunkCount = drawnChunkCount;
    }

    public int lastUploadCount() {
        return lastUploadCount;
    }

    @Override
    public BlockType blockAt(int worldX, int worldY, int worldZ) {
        if (worldY < 0 || worldY >= Chunk.SIZE_Y) {
            return BlockType.AIR;
        }

        ChunkPos chunkPos = new ChunkPos(Math.floorDiv(worldX, Chunk.SIZE_X), Math.floorDiv(worldZ, Chunk.SIZE_Z));
        ChunkHandle handle = chunkHandles.get(chunkPos);
        if (handle != null) {
            int localX = Math.floorMod(worldX, Chunk.SIZE_X);
            int localZ = Math.floorMod(worldZ, Chunk.SIZE_Z);
            return handle.chunk().getBlockType(localX, worldY, localZ);
        }
        return terrainGenerator.sampleBlock(worldX, worldY, worldZ);
    }

    @Override
    public int surfaceHeightAt(int worldX, int worldZ) {
        return terrainGenerator.sampleSurfaceHeight(worldX, worldZ);
    }

    @Override
    public void close() {
        executor.shutdownNow();
        for (ChunkHandle handle : chunkHandles.values()) {
            if (handle.mesh() != null) {
                handle.mesh().close();
            }
        }
        chunkHandles.clear();
    }

    private void enqueueRebuild(ChunkPos pos, boolean force) {
        if (!force && (queuedChunks.contains(pos) || buildingChunks.contains(pos))) {
            return;
        }

        long version = chunkVersions.merge(pos, 1L, (previous, one) -> previous + 1L);

        if (queuedChunks.add(pos)) {
            rebuildQueue.offer(new ChunkRebuildTask(
                    pos,
                    version,
                    distanceSquared(pos, centerChunkX, centerChunkZ),
                    buildSequence.incrementAndGet()
            ));
        }
    }

    private void rebuildWorker() {
        while (!Thread.currentThread().isInterrupted()) {
            ChunkRebuildTask task = null;
            try {
                task = rebuildQueue.take();
                queuedChunks.remove(task.position());

                if (!shouldAccept(task.position(), task.version())) {
                    continue;
                }

                buildingChunks.add(task.position());
                Chunk chunk = terrainGenerator.generate(task.position());
                BlockResolver resolver = (worldX, worldY, worldZ) -> {
                    if (worldY < 0 || worldY >= Chunk.SIZE_Y) {
                        return BlockType.AIR;
                    }
                    return terrainGenerator.sampleBlock(worldX, worldY, worldZ);
                };
                ChunkMeshData meshData = chunkMesher.buildMesh(chunk, resolver);
                completedChunks.add(new CompletedChunk(task.position(), task.version(), chunk, meshData));
            } catch (InterruptedException interruptedException) {
                Thread.currentThread().interrupt();
            } finally {
                if (task != null) {
                    buildingChunks.remove(task.position());
                }
            }
        }
    }

    private boolean shouldAccept(ChunkPos position, long version) {
        Long currentVersion = chunkVersions.get(position);
        return currentVersion != null
                && currentVersion == version
                && Math.abs(position.x() - centerChunkX) <= unloadDistance
                && Math.abs(position.z() - centerChunkZ) <= unloadDistance;
    }

    private int distanceSquared(ChunkPos pos, int chunkX, int chunkZ) {
        int dx = pos.x() - chunkX;
        int dz = pos.z() - chunkZ;
        return dx * dx + dz * dz;
    }

    public record ChunkHandle(Chunk chunk, GpuChunkMesh mesh) {
    }

    private record CompletedChunk(ChunkPos position, long version, Chunk chunk, ChunkMeshData meshData) {
    }

    private record ChunkRebuildTask(ChunkPos position, long version, int priority, long sequence)
            implements Comparable<ChunkRebuildTask> {
        @Override
        public int compareTo(ChunkRebuildTask other) {
            int priorityCompare = Integer.compare(priority, other.priority);
            if (priorityCompare != 0) {
                return priorityCompare;
            }
            return Long.compare(sequence, other.sequence);
        }
    }
}
