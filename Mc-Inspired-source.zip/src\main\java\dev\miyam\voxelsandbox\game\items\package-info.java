/**
 * Item definitions and runtime item stacks will live here once block interaction is in place.
 */
package dev.miyam.voxelsandbox.game.items;

